<?php

/* Load admin scripts and styles */
add_action( 'admin_enqueue_scripts', 'kobita_load_admin_scripts' );


/**
 * Load scripts and styles in admin
 *
 * It just wrapps two other separate functions for loading css and js files in admin
 *
 * @since  1.0
 */

function kobita_load_admin_scripts() {
	kobita_load_admin_css();
	kobita_load_admin_js();
}


/**
 * Load admin css files
 *
 * @since  1.0
 */

function kobita_load_admin_css() {

	global $pagenow, $typenow;

	//Load small admin style tweaks
	wp_enqueue_style( 'kobita-global', get_parent_theme_file_uri( '/assets/css/admin/global.css' ), false, KOBITA_THEME_VERSION, 'screen, print' );
}


/**
 * Load admin js files
 *
 * @since  1.0
 */

function kobita_load_admin_js() {

	global $pagenow, $typenow;

	wp_enqueue_script( 'kobita-global', get_parent_theme_file_uri( '/assets/js/admin/global.js' ), array( 'jquery' ), KOBITA_THEME_VERSION );

}

/**
 * Load editor styles
 *
 * @since  1.0
 */

function kobita_load_editor_styles() {

	if ( $fonts_link = kobita_generate_fonts_link() ) {
		add_editor_style( $fonts_link );
	}

	add_editor_style( get_parent_theme_file_uri( '/assets/css/admin/editor-style.css' ) );

}

/**
 * Load dynamic editor styles
 *
 * @since  1.0
 */

add_action( 'enqueue_block_editor_assets', 'kobita_block_editor_styles', 99 );

function kobita_block_editor_styles() {

	wp_register_style( 'kobita-editor-styles', false, KOBITA_THEME_VERSION );

	wp_enqueue_style( 'kobita-editor-styles' );
	wp_add_inline_style( 'kobita-editor-styles', kobita_generate_dynamic_editor_css() );

}
?>
