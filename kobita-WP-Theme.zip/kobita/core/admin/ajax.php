<?php

/**
 * Hide update notification and update theme version
 *
 * @since  1.0
 */

add_action('wp_ajax_kobita_update_version', 'kobita_update_version');

if(!function_exists('kobita_update_version')):
function kobita_update_version(){
	update_option('kobita_theme_version', KOBITA_THEME_VERSION);
	die();
}
endif;


/**
 * Hide welcome notification
 *
 * @since  1.0
 */

add_action('wp_ajax_kobita_hide_welcome', 'kobita_hide_welcome');

if(!function_exists('kobita_hide_welcome')):
function kobita_hide_welcome(){
	update_option('kobita_welcome_box_displayed', true);
	die();
}
endif;


?>