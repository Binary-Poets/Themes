<?php

/* Branding */
Redux::setSection( $opt_name , array(
        'icon'      => ' el-icon-smiley',
        'title'     => esc_html__( 'Branding', 'kobita' ),
        'desc'     => esc_html__( 'Personalize theme by adding your own images', 'kobita' ),
        'fields'    => array(

            array(
                'id'        => 'logo',
                'type'      => 'media',
                'url'       => true,
                'title'     => esc_html__( 'Logo', 'kobita' ),
                'subtitle'      => esc_html__( 'Upload your logo image here, or leave empty to show the website title instead.', 'kobita' ),
                'default'   => kobita_get_default_option( 'logo' ),
            ),

            array(
                'id'        => 'logo_retina',
                'type'      => 'media',
                'url'       => true,
                'title'     => esc_html__( 'Retina logo (2x)', 'kobita' ),
                'subtitle'      => esc_html__( 'Optionally upload another logo for devices with retina displays. It should be double the size of your standard logo', 'kobita' ),
                'default'   => kobita_get_default_option( 'logo_retina' ),
            ),

            array(
                'id'        => 'logo_custom_url',
                'type'      => 'text',
                'title'     => esc_html__( 'Custom logo URL', 'kobita' ),
                'subtitle'  => esc_html__( 'Optionally specify custom URL if you want logo to point out to some other page/website instead of your home page', 'kobita' ),
                'default'   => kobita_get_default_option( 'logo_custom_url' )
            )

        ) )
);


/* Stylings */
Redux::setSection( $opt_name , array(
        'icon'      => 'el-icon-brush',
        'title'     => esc_html__( 'Styling & Colors', 'kobita' ),
        'desc'     => esc_html__( 'Styling and color settings', 'kobita' ),
        'fields'    => array(

            array(
                'id'        => 'style',
                'type'      => 'image_select',
                'title'     => esc_html__( 'Theme style', 'kobita' ),
                'subtitle' => esc_html__( 'Choose general theme style', 'kobita' ),
                'options'   => array(
                    'material' => array( 'title' => esc_html__( 'Material', 'kobita' ),       'img' =>  get_parent_theme_file_uri( '/assets/img/admin/style_material.png' ) ),
                    'flat' => array( 'title' => esc_html__( 'Flat', 'kobita' ),       'img' =>  get_parent_theme_file_uri( '/assets/img/admin/style_flat.png' ) ),
                ),
                'default'   => kobita_get_default_option( 'style' ),
            ),

            array(
                'id' => 'color_header_bg',
                'type' => 'color',
                'title' => esc_html__( 'Header/cover background color', 'kobita' ),
                'subtitle' => esc_html__( 'This color applies to header and cover background', 'kobita' ),
                'transparent' => false,
                'default' => kobita_get_default_option( 'color_header_bg' ),
            ),

            array(
                'id' => 'cover_gradient',
                'type' => 'switch',
                'title' => esc_html__( 'Header/cover gradient', 'kobita' ),
                'subtitle' => esc_html__( 'Enable cover gradient', 'kobita' ),
                'default' => kobita_get_default_option( 'cover_gradient' ),
            ),

            array(
                'id' => 'cover_gradient_color',
                'type' => 'color',
                'title' => esc_html__( 'Second cover background color', 'kobita' ),
                'subtitle' => esc_html__( 'This color will be used to create gradient background', 'kobita' ),
                'default'  => kobita_get_default_option( 'cover_gradient_color' ),
                'transparent' => false,
                'required' => array( 'cover_gradient', '=', true )
            ),

            array(
                'id' => 'cover_gradient_orientation',
                'type' => 'select',
                'title' => esc_html__( 'Choose gradient orientation', 'kobita' ),
                'subtitle' => esc_html__( 'Select your desired orientation (direction) for background gradient', 'kobita' ),
                'transparent' => false,
                'options'  => array(
                    'to right top' => esc_html__( 'Left bottom to right top', 'kobita' ),
                    'to right' => esc_html__( 'Left to right', 'kobita' ),
                    'to right bottom' => esc_html__( 'Left top to right bottom', 'kobita' ),
                    'to bottom' => esc_html__( 'Top to bottom', 'kobita' ),
                    'to left bottom' => esc_html__( 'Right top to left bottom', 'kobita' ),
                    'to left' => esc_html__( 'Right to left', 'kobita' ),
                    'to left top' => esc_html__( 'Right bottom to left top', 'kobita' ),
                    'to top' => esc_html__( 'Bottom to top', 'kobita' ),
                    'circle' => esc_html__( 'Circle', 'kobita' ),
                ),
                'default'  => kobita_get_default_option( 'cover_gradient_orientation' ),
                'required' => array( 'cover_gradient', '=', true )
            ),

            array(
                'id' => 'cover_bg_media',
                'type' => 'radio',
                'title' => esc_html__( 'Cover background media', 'kobita' ),
                'subtitle' => esc_html__( 'Optionally, you can upload an image or a video as the default cover backgorund', 'kobita' ),
                'options' => array(
                    'image' => 'Image',
                    'video' => 'Video'
                ),
                'default' => kobita_get_default_option( 'cover_bg_media' ),
            ),

            array(
                'id' => 'cover_bg_img',
                'type' => 'media',
                'url'       => true,
                'title' => esc_html__( 'Cover background image', 'kobita' ),
                'subtitle' => esc_html__( 'Optionally, you can upload cover background image', 'kobita' ),
                'default' => kobita_get_default_option( 'cover_bg_img' ),
                'required' => array( 'cover_bg_media', '=', 'image' )
            ),

            array(
                'id' => 'cover_bg_video',
                'type' => 'media',
                'url'  => true,
                'mode' => false,
                'title' => esc_html__( 'Cover background video', 'kobita' ),
                'subtitle' => esc_html__( 'Optionally, you can upload cover background video', 'kobita' ),
                'desc' => esc_html__( 'Note: preferred formats is .mp4', 'kobita' ),
                'default' => kobita_get_default_option( 'cover_bg_video' ),
                'required' => array( 'cover_bg_media', '=', 'video' )
            ),

            array(
                'id' => 'cover_bg_video_image',
                'type' => 'media',
                'url'  => true,
                'mode' => false,
                'title' => esc_html__( 'Video placeholder image', 'kobita' ),
                'subtitle' => esc_html__( 'Optionally, you can upload an image to display on mobile devices that don\'t support background video', 'kobita' ),
                'default' => kobita_get_default_option( 'cover_bg_video_image' ),
                'required' => array( 'cover_bg_media', '=', 'video' )
            ),

            array(
                'id'        => 'cover_bg_opacity',
                'type'      => 'slider',
                'title'     => esc_html__( 'Cover background color opacity', 'kobita' ),
                'subtitle'  => esc_html__( 'If background image is uploaded, you can set background color opacity ', 'kobita' ),
                'default' => kobita_get_default_option( 'cover_bg_opacity' ),
                'resolution' => 0.1,
                'min' => 0,
                'step' => .1,
                'max' => 1,
                'display_value' => 'label'
            ),

            array(
                'id' => 'color_header_txt',
                'type' => 'color',
                'title' => esc_html__( 'Header/cover text color', 'kobita' ),
                'subtitle' => esc_html__( 'This color applies to header and cover text', 'kobita' ),
                'transparent' => false,
                'default' => kobita_get_default_option( 'color_header_txt' ),
            ),


            array(
                'id' => 'color_body_bg',
                'type' => 'color',
                'title' => esc_html__( 'Body background color', 'kobita' ),
                'subtitle' => esc_html__( 'This color applies to body background (used only in "material" version)', 'kobita' ),
                'transparent' => false,
                'default' => kobita_get_default_option( 'color_body_bg' ),
                'required' => array( 'style', '=', 'material' )
            ),

            array(
                'id' => 'color_content_bg',
                'type' => 'color',
                'title' => esc_html__( 'Content background color', 'kobita' ),
                'subtitle' => esc_html__( 'This is your main content background color', 'kobita' ),
                'transparent' => false,
                'default' => kobita_get_default_option( 'color_content_bg' ),
            ),


            array(
                'id' => 'color_content_h',
                'type' => 'color',
                'title' => esc_html__( 'Heading color', 'kobita' ),
                'subtitle' => esc_html__( 'This color applies to post/page titles, widget titles, etc... ', 'kobita' ),
                'transparent' => false,
                'default' => kobita_get_default_option( 'color_content_h' ),
            ),

            array(
                'id' => 'color_content_txt',
                'type' => 'color',
                'title' => esc_html__( 'Text color', 'kobita' ),
                'subtitle' => esc_html__( 'This color applies to standard text', 'kobita' ),
                'transparent' => false,
                'default' => kobita_get_default_option( 'color_content_txt' ),
            ),

            array(
                'id' => 'color_content_acc',
                'type' => 'color',
                'title' => esc_html__( 'Accent color', 'kobita' ),
                'subtitle' => esc_html__( 'This color applies to links, buttons and some other special elements', 'kobita' ),
                'transparent' => false,
                'default' => kobita_get_default_option( 'color_content_acc' ),
            ),

            array(
                'id' => 'color_content_meta',
                'type' => 'color',
                'title' => esc_html__( 'Meta color', 'kobita' ),
                'subtitle' => esc_html__( 'This color applies to miscellaneous elements like post meta data (author link, date, etc...)', 'kobita' ),
                'transparent' => false,
                'default' => kobita_get_default_option( 'color_content_meta' ),
            ),

            array(
                'id' => 'color_footer_bg',
                'type' => 'color',
                'title' => esc_html__( 'Footer background color', 'kobita' ),
                'subtitle' => esc_html__( 'This color applies to footer background', 'kobita' ),
                'transparent' => false,
                'default' => kobita_get_default_option( 'color_footer_bg' ),
            ),


            array(
                'id' => 'color_footer_txt',
                'type' => 'color',
                'title' => esc_html__( 'Footer text color', 'kobita' ),
                'subtitle' => esc_html__( 'This color applies to footer text', 'kobita' ),
                'transparent' => false,
                'default' => kobita_get_default_option( 'color_footer_txt' ),
            ),

            array(
                'id' => 'color_footer_acc',
                'type' => 'color',
                'title' => esc_html__( 'Footer accent color', 'kobita' ),
                'subtitle' => esc_html__( 'This color applies to footer links, buttons and some other special elements', 'kobita' ),
                'transparent' => false,
                'default' => kobita_get_default_option( 'color_footer_acc' ),
            ),


        ) )
);



/* Header */
Redux::setSection( $opt_name , array(
        'icon'      => 'el-icon-bookmark',
        'title'     => esc_html__( 'Header', 'kobita' ),
        'desc'     => esc_html__( 'Modify and style your header', 'kobita' ),
        'fields'    => array(

            array(
                'id'        => 'header_layout',
                'type'      => 'image_select',
                'title'     => esc_html__( 'Header layout', 'kobita' ),
                'subtitle' => esc_html__( 'Choose a layout for your header', 'kobita' ),
                'options'   => kobita_get_header_layouts(),
                'default' => kobita_get_default_option( 'header_layout' ),

            ),

            array(
                'id'        => 'header_elements',
                'type'      => 'checkbox',
                'multi'     => true,
                'title'     => esc_html__( 'Header elements', 'kobita' ),
                'subtitle' => esc_html__( 'Check elements you want to display in header ', 'kobita' ),
                'options'   => array(
                    'main-menu' => esc_html__( 'Main Navigation', 'kobita' ),
                    'sidebar-button' => esc_html__( 'Sidebar (hamburger icon)', 'kobita' ),
                    'search-dropdown' => esc_html__( 'Search dropdown', 'kobita' ),
                    'social-menu-dropdown' => esc_html__( 'Social icons dropdown', 'kobita' ),
                    'site-desc' => esc_html__( 'Site description', 'kobita' ),
                ),
                'default' => kobita_get_default_option( 'header_elements' ),
            ),

            array(
                'id' => 'header_height',
                'type' => 'text',
                'class' => 'small-text',
                'title' => esc_html__( 'Header height', 'kobita' ),
                'subtitle' => esc_html__( 'Specify height for your header/navigation area', 'kobita' ),
                'desc' => esc_html__( 'Note: Height value is in px.', 'kobita' ),
                'default' => kobita_get_default_option( 'header_height' ),
                'validate' => 'numeric'
            ),


            array(
                'id'        => 'header_orientation',
                'type'      => 'image_select',
                'title'     => esc_html__( 'Header orientation', 'kobita' ),
                'subtitle' => esc_html__( 'Choose if header elements follow site content or browser width ', 'kobita' ),
                'options'   => array(
                    'content' => array( 'title' => esc_html__( 'Site content', 'kobita' ),       'img' =>  get_parent_theme_file_uri( '/assets/img/admin/header_content.png' ) ),
                    'wide' => array( 'title' => esc_html__( 'Browser (full width)', 'kobita' ),       'img' =>  get_parent_theme_file_uri( '/assets/img/admin/header_wide.png' ) ),
                ),
                'default' => kobita_get_default_option( 'header_orientation' ),

            ),

            array(
                'id'        => 'header_sticky',
                'type'      => 'switch',
                'title'     => esc_html__( 'Enable sticky header', 'kobita' ),
                'subtitle'  => esc_html__( 'Check if you want to enable sticky header', 'kobita' ),
                'default' => kobita_get_default_option( 'header_sticky' ),
            ),


        ) ) );



/* Footer */
Redux::setSection( $opt_name, array(
        'icon'   => 'el-icon-bookmark-empty',
        'title'  => esc_html__( 'Footer', 'kobita' ),
        'desc'   => esc_html__( 'Manage the options for your footer area', 'kobita' ),
        'fields' => array(

            array(
                'id'       => 'footer_layout',
                'type'     => 'image_select',
                'title'    => esc_html__( 'Footer area layout', 'kobita' ),
                'subtitle' => esc_html__( 'Choose a layout for your footer widgetized area', 'kobita' ),
                'desc'     => wp_kses_post( sprintf( __( 'Note: Each column represents one Footer Sidebar in <a href="%s">Apperance -> Widgets</a> settings.', 'kobita' ), admin_url( 'widgets.php' ) ) ),
                'options'  => kobita_get_footer_layouts(),
                'default' => kobita_get_default_option( 'footer_layout' ),
            ),

        ),
    )
);



/* Layout settings */
Redux::setSection( $opt_name , array(
        'icon'      => 'el-icon-th-large',
        'title'     => esc_html__( 'Post Layouts', 'kobita' ),
        'heading' => false,
        'fields'    => array(
        ) )
);


/* Layout A */
Redux::setSection( $opt_name , array(
        'icon'      => '',
        'title'     => esc_html__( 'Layout A', 'kobita' ),
        'heading' => false,
        'subsection' => true,
        'fields'    => array(

            array(
                'id'        => 'section_layout_a',
                'type'      => 'kobita_section',
                'title'     => '<img src="'.esc_url( get_parent_theme_file_uri( '/assets/img/admin/layout_a.png' ) ).'"/>'.esc_html__( 'Layout A', 'kobita' ),
                'subtitle'  => esc_html__( 'Manage options for posts displayed in Layout A', 'kobita' ),
                'indent'   => false
            ),

            array(
                'id'        => 'layout_a_dropcap',
                'type'      => 'switch',
                'title'     => esc_html__( 'Display dropcap', 'kobita' ),
                'subtitle'  => esc_html__( 'Check if you want to display dropcap (first letter)', 'kobita' ),
                'default' => kobita_get_default_option( 'layout_a_dropcap' ),
            ),

            array(
                'id'        => 'layout_a_fimg',
                'type'      => 'switch',
                'title'     => esc_html__( 'Display featured image', 'kobita' ),
                'subtitle'  => esc_html__( 'Check if you want to display featured image', 'kobita' ),
                'default' => kobita_get_default_option( 'layout_a_fimg' ),
            ),

            array(
                'id'        => 'layout_a_meta',
                'type'      => 'sortable',
                'mode'      => 'checkbox',
                'title'     => esc_html__( 'Meta data', 'kobita' ),
                'subtitle'  => esc_html__( 'Check and re-order which meta data you want to display', 'kobita' ),
                'options'   => kobita_get_meta_opts(),
                'default' => kobita_get_default_option( 'layout_a_meta' ),
            ),

            array(
                'id' => 'layout_a_content',
                'type' => 'radio',
                'title' => esc_html__( 'Content type', 'kobita' ),
                'options' => array(
                    'excerpt' =>  esc_html__( 'Excerpt (automatically limit number of characters)', 'kobita' ),
                    'content' =>  esc_html__( 'Full content (optionally split with "<--more-->" tag)', 'kobita' ),
                ),
                'subtitle' => esc_html__( 'Choose content type', 'kobita' ),
                'default' => kobita_get_default_option( 'layout_a_content' ),
            ),

            array(
                'id' => 'layout_a_excerpt_limit',
                'type' => 'text',
                'class' => 'small-text',
                'title' => esc_html__( 'Excerpt limit', 'kobita' ),
                'subtitle' => esc_html__( 'Specify your excerpt limit', 'kobita' ),
                'desc' => esc_html__( 'Note: Value represents number of characters', 'kobita' ),
                'default' => kobita_get_default_option( 'layout_a_excerpt_limit' ),
                'validate' => 'numeric',
                'required'  => array( 'layout_a_content', '=', 'excerpt' )
            ),

            array(
                'id'        => 'layout_a_buttons',
                'type'      => 'sortable',
                'mode'      => 'checkbox',
                'title'     => esc_html__( 'Buttons', 'kobita' ),
                'subtitle'  => esc_html__( 'Check and re-order which buttons you want to display', 'kobita' ),
                'options'   => kobita_get_button_opts(),
                'default' => kobita_get_default_option( 'layout_a_buttons' ),
            ),


        ) ) );

/* Layout B */
Redux::setSection( $opt_name , array(
        'icon'      => '',
        'title'     => esc_html__( 'Layout B', 'kobita' ),
        'heading' => false,
        'subsection' => true,
        'fields'    => array(
            array(
                'id'        => 'section_layout_b',
                'type'      => 'kobita_section',
                'title'     => '<img src="'.esc_url( get_parent_theme_file_uri( '/assets/img/admin/layout_b.png' ) ).'"/>'.esc_html__( 'Layout B', 'kobita' ),
                'subtitle'  => esc_html__( 'Manage options for posts displayed in Layout B', 'kobita' ),
                'indent'   => false
            ),

            array(
                'id'        => 'layout_b_fimg',
                'type'      => 'switch',
                'title'     => esc_html__( 'Display featured image', 'kobita' ),
                'subtitle'  => esc_html__( 'Check if you want to display featured image', 'kobita' ),
                'default' => kobita_get_default_option( 'layout_b_fimg' ),
            ),

            array(
                'id'        => 'layout_b_meta',
                'type'      => 'sortable',
                'mode'      => 'checkbox',
                'title'     => esc_html__( 'Meta data', 'kobita' ),
                'subtitle'  => esc_html__( 'Check and re-order which meta data you want to display', 'kobita' ),
                'options'   => kobita_get_meta_opts(),
                'default' => kobita_get_default_option( 'layout_b_meta' ),
            ),

            array(
                'id'        => 'layout_b_excerpt',
                'type'      => 'switch',
                'title'     => esc_html__( 'Display text excerpt', 'kobita' ),
                'subtitle'  => esc_html__( 'Check if you want to display excerpt', 'kobita' ),
                'default' => kobita_get_default_option( 'layout_b_excerpt' ),
            ),

            array(
                'id' => 'layout_b_excerpt_limit',
                'type' => 'text',
                'class' => 'small-text',
                'title' => esc_html__( 'Excerpt limit', 'kobita' ),
                'subtitle' => esc_html__( 'Specify your excerpt limit', 'kobita' ),
                'desc' => esc_html__( 'Note: Value represents number of characters', 'kobita' ),
                'default' => kobita_get_default_option( 'layout_b_excerpt_limit' ),
                'validate' => 'numeric',
                'required'  => array( 'layout_b_excerpt', '=', true )
            ),

            array(
                'id'        => 'layout_b_buttons',
                'type'      => 'sortable',
                'mode'      => 'checkbox',
                'title'     => esc_html__( 'Buttons', 'kobita' ),
                'subtitle'  => esc_html__( 'Check and re-order which buttons you want to display', 'kobita' ),
                'options'   => kobita_get_button_opts(),
                'default' => kobita_get_default_option( 'layout_b_buttons' ),
            ),


        ) ) );


/* Layout C */
Redux::setSection( $opt_name , array(
        'icon'      => '',
        'title'     => esc_html__( 'Layout C', 'kobita' ),
        'heading' => false,
        'subsection' => true,
        'fields'    => array(
            array(
                'id'        => 'section_layout_c',
                'type'      => 'kobita_section',
                'title'     => '<img src="'.esc_url( get_parent_theme_file_uri( '/assets/img/admin/layout_c.png' ) ).'"/>'.esc_html__( 'Layout C', 'kobita' ),
                'subtitle'  => esc_html__( 'Manage options for posts displayed in Layout C', 'kobita' ),
                'indent'   => false
            ),

            array(
                'id'        => 'layout_c_dropcap',
                'type'      => 'switch',
                'title'     => esc_html__( 'Display dropcap', 'kobita' ),
                'subtitle'  => esc_html__( 'Check if you want to display dropcap (first letter)', 'kobita' ),
                'default' => kobita_get_default_option( 'layout_c_dropcap' ),
            ),

            array(
                'id'        => 'layout_c_fimg',
                'type'      => 'switch',
                'title'     => esc_html__( 'Display featured image', 'kobita' ),
                'subtitle'  => esc_html__( 'Check if you want to display featured image', 'kobita' ),
                'default' => kobita_get_default_option( 'layout_c_fimg' ),
            ),

            array(
                'id'        => 'layout_c_meta',
                'type'      => 'sortable',
                'mode'      => 'checkbox',
                'title'     => esc_html__( 'Meta data', 'kobita' ),
                'subtitle'  => esc_html__( 'Check and re-order which meta data you want to display', 'kobita' ),
                'options'   => kobita_get_meta_opts(),
                'default' => kobita_get_default_option( 'layout_c_meta' ),
            ),


        ) ) );

/* Home Page */

if ( get_option( 'show_on_front' ) != 'page' ) {

    $info = array(
        'id' => 'home_setup_info',
        'type' => 'info',
        'style' => 'critical',
        'title' => esc_html__( 'Important note:', 'kobita' ),
        'subtitle' => wp_kses_post( sprintf( __( 'Your front page is currently set to display <strong>"latest posts"</strong>. In order to use these options, you need to set your front page option as <strong>"static page"</strong> inside <a href="%s" target="_blank">Settings->Reading</a>.', 'kobita' ), admin_url( 'options-reading.php' ) ) ),
    );
} else {

    $info = array();
}


Redux::setSection( $opt_name , array(
        'icon'      => 'el-icon-home',
        'title'     => esc_html__( 'Home Page', 'kobita' ),
        'heading' => false,
        'fields'    => array(

            $info,

            array(
                'id'        => 'section_front_page_cover',
                'type'      => 'section',
                'title'     => esc_html__( 'Cover area', 'kobita' ),
                'subtitle'  => esc_html__( 'Manage options for home page cover area', 'kobita' ),
                'indent'    => false
            ),

            array(
                'id' => 'front_page_cover',
                'type' => 'radio',
                'title' => esc_html__( 'Cover area displays', 'kobita' ),
                'subtitle' => esc_html__( 'Choose what to display in cover area', 'kobita' ),
                'options'   => array(
                    'posts' => esc_html__( 'Posts (slider)', 'kobita' ),
                    'bloginfo' => esc_html__( 'Site title & description (tagline)', 'kobita' ),
                    'content' => esc_html__( 'Page content', 'kobita' ),
                    'title' => esc_html__( 'Page title', 'kobita' ),
                    '0' => esc_html__( 'None (do not display cover)', 'kobita' ),
                ),
                'default' => kobita_get_default_option( 'front_page_cover' ),
            ),



            array(
                'id' => 'front_page_cover_posts',
                'type' => 'radio',
                'title' => esc_html__( 'Cover area chooses from', 'kobita' ),
                'subtitle' => esc_html__( 'Choose which posts to display', 'kobita' ),
                'options'   => array(
                    'date' => esc_html__( 'Latest posts', 'kobita' ),
                    'comment_count' => esc_html__( 'Most commented posts', 'kobita' ),
                    'manual' => esc_html__( 'Manually picked posts', 'kobita' )
                ),
                'default' => kobita_get_default_option( 'front_page_cover_posts' ),
                'required' => array( 'front_page_cover', '=', 'posts' )
            ),

            array(
                'id'        => 'front_page_cover_posts_cat',
                'type'      => 'select',
                'data'      => 'categories',
                'multi'     => true,
                'title'     => esc_html__( 'In category', 'kobita' ),
                'subtitle'  => esc_html__( 'Check if you want to display posts from one or more specific categories', 'kobita' ),
                'desc'      => esc_html__( 'Note: Leave empty for "all categories"', 'kobita' ),
                'default' => kobita_get_default_option( 'front_page_cover_posts_cat' ),
                'required' => array( array( 'front_page_cover', '=', 'posts' ), array( 'front_page_cover_posts', '!=', 'manual' ) )

            ),

            array(
                'id'        => 'front_page_cover_posts_tag',
                'type'      => 'select',
                'data'      => 'tags',
                'multi'     => true,
                'title'     => esc_html__( 'Tagged with', 'kobita' ),
                'subtitle'  => esc_html__( 'Check if you want to display posts that are tagged with one or more specific tags', 'kobita' ),
                'desc'      => esc_html__( 'Note: Leave empty for "all tags"', 'kobita' ),
                'default' => kobita_get_default_option( 'front_page_cover_posts_tag' ),
                'required' => array( array( 'front_page_cover', '=', 'posts' ), array( 'front_page_cover_posts', '!=', 'manual' ) )
            ),


            array(
                'id'        => 'front_page_cover_posts_manual',
                'type'      => 'text',
                'title'     => esc_html__( 'Pick posts manually ', 'kobita' ),
                'subtitle'  => esc_html__( 'Use this option to manually specify posts by their IDs', 'kobita' ),
                'desc'      => esc_html__( 'Note: Separate post IDs by comma, i.e. 43,56,26,187', 'kobita' ),
                'default' => kobita_get_default_option( 'front_page_cover_posts_manual' ),
                'required' => array( array( 'front_page_cover', '=', 'posts' ), array( 'front_page_cover_posts', '=', 'manual' ) )
            ),

            array(
                'id'        => 'front_page_cover_posts_num',
                'type'      => 'text',
                'class'     => 'small-text',
                'title'     => esc_html__( 'Number of post to display', 'kobita' ),
                'subtitle'  => esc_html__( 'Choose how many posts to display', 'kobita' ),
                'required'  => array( array( 'front_page_cover', '=', 'posts' ), array( 'front_page_cover_posts', '!=', 'manual' ) ),
                'validate'  => 'numeric',
                'default' => kobita_get_default_option( 'front_page_cover_posts_num' ),
            ),

            array(
                'id'        => 'front_page_cover_posts_unique',
                'type'      => 'switch',
                'title'     => esc_html__( 'Unique posts', 'kobita' ),
                'subtitle'  => esc_html__( 'If you check this option, cover posts will be excluded from the main post section below', 'kobita' ),
                'required' => array( 'front_page_cover', '=', 'posts' ),
                'default' => kobita_get_default_option( 'front_page_cover_posts_unique' ),
            ),

            array(
                'id'        => 'front_page_cover_dropcap',
                'type'      => 'switch',
                'title'     => esc_html__( 'Display dropcap', 'kobita' ),
                'subtitle'  => esc_html__( 'Check if you want to display dropcap (first letter)', 'kobita' ),
                'default' => kobita_get_default_option( 'front_page_cover_dropcap' ),
                'required' => array( 'front_page_cover', '!=', '0' )
            ),



            array(
                'id'        => 'layout_cover_meta',
                'type'      => 'sortable',
                'mode'      => 'checkbox',
                'title'     => esc_html__( 'Display meta data', 'kobita' ),
                'subtitle'  => esc_html__( 'Check and re-order which meta data you want to display for post in cover area', 'kobita' ),
                'options'   => kobita_get_meta_opts(),
                'default' => kobita_get_default_option( 'layout_cover_meta' ),
                'required' => array( 'front_page_cover', '=', 'posts' )
            ),

            array(
                'id'        => 'layout_cover_buttons',
                'type'      => 'sortable',
                'mode'      => 'checkbox',
                'title'     => esc_html__( 'Buttons', 'kobita' ),
                'subtitle'  => esc_html__( 'Check and re-order which buttons you want to display for post in cover area', 'kobita' ),
                'options'   => kobita_get_button_opts(),
                'default' => kobita_get_default_option( 'layout_cover_buttons' ),
                'required' => array( 'front_page_cover', '=', 'posts' )
            ),

            array(
                'id'        => 'front_page_cover_posts_fimg',
                'type'      => 'switch',
                'title'     => esc_html__( 'Display cover post featured image', 'kobita' ),
                'subtitle'  => esc_html__( 'Check if you want to display post featured images as cover background', 'kobita' ),
                'required' => array( 'front_page_cover', '=', 'posts' ),
                'default' => kobita_get_default_option( 'front_page_cover_posts_fimg' ),
            ),

            array(
                'id' => 'front_page_cover_autoplay',
                'type' => 'switch',
                'title' => esc_html__( 'Autoplay (rotate)', 'kobita' ),
                'subtitle' => esc_html__( 'Check if you want to auto rotate items in cover area slider', 'kobita' ),
                'default' => kobita_get_default_option( 'front_page_cover_autoplay' ),
                'required'  => array( 'front_page_cover', '=', 'posts' )
            ),
            array(
                'id' => 'front_page_cover_autoplay_time',
                'type' => 'text',
                'class' => 'small-text',
                'title' => esc_html__( 'Autoplay time', 'kobita' ),
                'subtitle' => esc_html__( 'Specify autoplay time per slide', 'kobita' ),
                'desc' => esc_html__( 'Note: Please specify number in seconds', 'kobita' ),
                'default' => kobita_get_default_option( 'front_page_cover_autoplay_time' ),
                'validate' => 'numeric',
                'required'  => array( 'front_page_cover_autoplay', '=', true )
            ),

            array(
                'id' => 'front_page_cover_on_first_page',
                'type' => 'checkbox',
                'title' => esc_html__( 'Enable Cover section on first page only', 'kobita' ),
                'subtitle' => esc_html__( 'Cover section will not be displyed on page 2,3,4, etc...', 'kobita' ),
                'default' => kobita_get_default_option( 'front_page_cover_on_first_page' ),
                'required' => array( 'front_page_cover', '!=', '0' )
            ),

            array(
                'id'        => 'section_front_page_intro',
                'type'      => 'section',
                'title'     => esc_html__( 'Intro section', 'kobita' ),
                'subtitle'  => esc_html__( 'Manage options for home page introduction section', 'kobita' ),
                'indent'    => false
            ),

            array(
                'id' => 'front_page_intro',
                'type' => 'radio',
                'title' => esc_html__( 'Intro section displays', 'kobita' ),
                'subtitle' => esc_html__( 'Choose what to display in intro section', 'kobita' ),
                'options'   => array(
                    'content' => esc_html__( 'Page content', 'kobita' ),
                    'title_content' => esc_html__( 'Page title & page content', 'kobita' ),
                    '0' => esc_html__( 'None (do not display intro section)', 'kobita' ),
                ),
                'default' => kobita_get_default_option( 'front_page_intro' ),
            ),

            array(
                'id' => 'front_page_intro_on_first_page',
                'type' => 'checkbox',
                'title' => esc_html__( 'Enable Intro section on first page only', 'kobita' ),
                'subtitle' => esc_html__( 'Intro section will not be displyed on page 2,3,4, etc...', 'kobita' ),
                'default' => kobita_get_default_option( 'front_page_intro_on_first_page' ),
                'required' => array( 'front_page_intro', '!=', '0' )

            ),

            array(
                'id'        => 'section_front_page_posts',
                'type'      => 'section',
                'title'     => esc_html__( 'Posts section', 'kobita' ),
                'subtitle'  => esc_html__( 'Manage options for home page posts section', 'kobita' ),
                'indent'    => false
            ),

            array(
                'id' => 'front_page_posts',
                'type' => 'radio',
                'title' => esc_html__( 'Posts section chooses from', 'kobita' ),
                'subtitle' => esc_html__( 'Choose which posts to display', 'kobita' ),
                'options'   => array(
                    'date' => esc_html__( 'Latest posts', 'kobita' ),
                    'comment_count' => esc_html__( 'Most commented posts', 'kobita' ),
                    'manual' => esc_html__( 'Manually picked posts', 'kobita' ),
                    '0' => esc_html__( 'None (do not display post section)', 'kobita' ),
                ),
                'default' => kobita_get_default_option( 'front_page_posts' ),
            ),

            array(
                'id'        => 'front_page_posts_cat',
                'type'      => 'select',
                'data'      => 'categories',
                'multi'     => true,
                'title'     => esc_html__( 'In category', 'kobita' ),
                'subtitle'  => esc_html__( 'Check if you want to display posts from one or more specific categories', 'kobita' ),
                'desc'      => esc_html__( 'Note: Leave empty for "all categories"', 'kobita' ),
                'default' => kobita_get_default_option( 'front_page_posts_cat' ),
                'required' => array( array( 'front_page_posts', '!=', 'manual' ), array( 'front_page_posts', '!=', '0' ) )
            ),

            array(
                'id'        => 'front_page_posts_tag',
                'type'      => 'select',
                'data'      => 'tags',
                'multi'     => true,
                'title'     => esc_html__( 'Tagged with', 'kobita' ),
                'subtitle'  => esc_html__( 'Check if you want to display posts that are tagged with one or more specific tags', 'kobita' ),
                'desc'      => esc_html__( 'Note: Leave empty for "all tags"', 'kobita' ),
                'default' => kobita_get_default_option( 'front_page_posts_tag' ),
                'required' => array( array( 'front_page_posts', '!=', 'manual' ), array( 'front_page_posts', '!=', '0' ) )
            ),


            array(
                'id'        => 'front_page_posts_manual',
                'type'      => 'text',
                'title'     => esc_html__( 'Pick posts manually ', 'kobita' ),
                'subtitle'  => esc_html__( 'Use this option to manually specify posts by their IDs', 'kobita' ),
                'desc'      => esc_html__( 'Note: Separate post IDs by comma, i.e. 43,56,26,187', 'kobita' ),
                'default' => kobita_get_default_option( 'front_page_posts_manual' ),
                'required' => array( 'front_page_posts', '=', 'manual' )
            ),

            array(
                'id'        => 'front_page_posts_ppp',
                'type'      => 'radio',
                'title'     => esc_html__( 'Posts per page', 'kobita' ),
                'subtitle'  => esc_html__( 'Choose how many post you want to display', 'kobita' ),
                'options'   => array(
                    'inherit' => wp_kses_post( sprintf( __( 'Inherit from global option in <a href="%s">Settings->Reading</a>', 'kobita' ), admin_url( 'options-reading.php' ) ) ),
                    'custom' => esc_html__( 'Custom number', 'kobita' )
                ),
                'default' => kobita_get_default_option( 'front_page_posts_ppp' ),
                'required' => array( array( 'front_page_posts', '!=', 'manual' ), array( 'front_page_posts', '!=', '0' ) )
            ),



            array(
                'id'        => 'front_page_posts_num',
                'type'      => 'text',
                'class'     => 'small-text',
                'title'     => esc_html__( 'Number of posts per page', 'kobita' ),
                'default' => kobita_get_default_option( 'front_page_posts_num' ),
                'required'  => array( 'front_page_posts_ppp', '=', 'custom' ),
                'validate'  => 'numeric'
            ),

            array(
                'id'        => 'front_page_posts_layout',
                'type'      => 'image_select',
                'title'     => esc_html__( 'Layout', 'kobita' ),
                'subtitle'  => esc_html__( 'Choose a layout for home page posts', 'kobita' ),
                'options'   => kobita_get_main_layouts(),
                'required'  => array( 'front_page_posts', '!=', '0' ),
                'default' => kobita_get_default_option( 'front_page_posts_layout' ),
            ),

            array(
                'id'        => 'front_page_posts_pagination',
                'type'      => 'image_select',
                'title'     => esc_html__( 'Pagination', 'kobita' ),
                'subtitle'  => esc_html__( 'Choose a pagination for home page posts', 'kobita' ),
                'options'   => kobita_get_pagination_layouts(),
                'required'  => array( array( 'front_page_posts', '!=', 'manual' ), array( 'front_page_posts', '!=', '0' ) ),
                'default' => kobita_get_default_option( 'front_page_posts_pagination' ),
            ),

        ) )
);


/* Archives */
Redux::setSection( $opt_name ,  array(
        'icon'      => 'el-icon-file-edit',
        'title'     => esc_html__( 'Archive Templates', 'kobita' ),
        'desc'     => esc_html__( 'Manage settings for your archive templates', 'kobita' ),
        'fields'    => array(

            array(
                'id' => 'archive_cover',
                'type' => 'switch',
                'title' => esc_html__( 'Display cover', 'kobita' ),
                'subtitle' => esc_html__( 'Check if you want to display cover area on archive templates', 'kobita' ),
                'default' => kobita_get_default_option( 'archive_cover' ),
            ),

            array(
                'id'        => 'archive_dropcap',
                'type'      => 'switch',
                'title'     => esc_html__( 'Display dropcap in cover', 'kobita' ),
                'subtitle'  => esc_html__( 'If cover is used, dropcap will be displayed', 'kobita' ),
                'default' => kobita_get_default_option( 'archive_dropcap' ),
            ),

            array(
                'id' => 'archive_description',
                'type' => 'switch',
                'title' => esc_html__( 'Display archive description', 'kobita' ),
                'subtitle' => esc_html__( 'Enable this option if you want to display category/tag/author description', 'kobita' ),
                'default' => kobita_get_default_option( 'archive_description' ),
            ),

            array(
                'id'        => 'archive_layout',
                'type'      => 'image_select',
                'title'     => esc_html__( 'Main layout', 'kobita' ),
                'subtitle'  => esc_html__( 'Choose your main post layout', 'kobita' ),
                'options'   => kobita_get_main_layouts(),
                'default' => kobita_get_default_option( 'archive_layout' ),
            ),


            array(
                'id'        => 'archive_ppp',
                'type'      => 'radio',
                'title'     => esc_html__( 'Posts per page', 'kobita' ),
                'subtitle'  => esc_html__( 'Choose how many posts per page you want to display', 'kobita' ),
                'options'   => array(
                    'inherit' => wp_kses( sprintf( __( 'Inherit from global option in <a href="%s">Settings->Reading</a>', 'kobita' ), admin_url( 'options-reading.php' ) ), wp_kses_allowed_html( 'post' ) ),
                    'custom' => esc_html__( 'Custom number', 'kobita' )
                ),
                'default' => kobita_get_default_option( 'archive_ppp' ),
            ),

            array(
                'id'        => 'archive_ppp_num',
                'type'      => 'text',
                'class'     => 'small-text',
                'title'     => esc_html__( 'Number of posts per page', 'kobita' ),
                'default' => kobita_get_default_option( 'archive_ppp_num' ),
                'required'  => array( 'archive_ppp', '=', 'custom' ),
                'validate'  => 'numeric'
            ),

            array(
                'id'        => 'archive_pagination',
                'type'      => 'image_select',
                'title'     => esc_html__( 'Pagination', 'kobita' ),
                'subtitle'  => esc_html__( 'Choose a pagination type for archive templates', 'kobita' ),
                'options'   => kobita_get_pagination_layouts(),
                'default' => kobita_get_default_option( 'archive_pagination' ),
            ),

        ) )
);


/* Category */
Redux::setSection( $opt_name ,  array(
        'title'      => esc_html__( 'Category Templates', 'kobita' ),
        'desc'       => esc_html__( 'Manage settings for your category templates', 'kobita' ),
        'subsection' => true,
        'fields'     => array(

            array(
                'id'      => 'category_settings_type',
                'type'    => 'radio',
                'title'   => esc_html__( 'Settings', 'kobita' ),
                'options' => array(
                    'inherit' => esc_html__( 'Inherit from global archive options', 'kobita' ),
                    'custom'  => esc_html__( 'Customize', 'kobita' ),
                ),
                'default' => kobita_get_default_option( 'category_settings_type' ),
            ),

            array(
                'id'       => 'category_cover',
                'type'     => 'switch',
                'title'    => esc_html__( 'Display cover', 'kobita' ),
                'subtitle' => esc_html__( 'Check if you want to display cover area on category templates', 'kobita' ),
                'default' => kobita_get_default_option( 'category_cover' ),
                'required' => array( 'category_settings_type', '=', 'custom' ),
            ),

            array(
                'id'       => 'category_layout',
                'type'     => 'image_select',
                'title'    => esc_html__( 'Main layout', 'kobita' ),
                'subtitle' => esc_html__( 'Choose your main post layout', 'kobita' ),
                'options'  => kobita_get_main_layouts(),
                'default' => kobita_get_default_option( 'category_layout' ),
                'required' => array( 'category_settings_type', '=', 'custom' ),
            ),


            array(
                'id'       => 'category_ppp',
                'type'     => 'radio',
                'title'    => esc_html__( 'Posts per page', 'kobita' ),
                'subtitle' => esc_html__( 'Choose how many posts per page you want to display', 'kobita' ),
                'options'  => array(
                    'inherit' => wp_kses( sprintf( __( 'Inherit from global option in <a href="%s">Settings->Reading</a>', 'kobita' ), admin_url( 'options-reading.php' ) ), wp_kses_allowed_html( 'post' ) ),
                    'custom'  => esc_html__( 'Custom number', 'kobita' ),
                ),
                'default' => kobita_get_default_option( 'category_ppp' ),
                'required' => array( 'category_settings_type', '=', 'custom' ),
            ),

            array(
                'id'       => 'category_ppp_num',
                'type'     => 'text',
                'class'    => 'small-text',
                'title'    => esc_html__( 'Number of posts per page', 'kobita' ),
                'default' => kobita_get_default_option( 'category_ppp_num' ),
                'validate' => 'numeric',
                'required' => array(
                    array( 'category_settings_type', '=', 'custom' ),
                    array( 'category_ppp', '=', 'custom' ),
                ),
            ),

            array(
                'id'       => 'category_pagination',
                'type'     => 'image_select',
                'title'    => esc_html__( 'Pagination', 'kobita' ),
                'subtitle' => esc_html__( 'Choose a pagination type for category templates', 'kobita' ),
                'options'  => kobita_get_pagination_layouts(),
                'default' => kobita_get_default_option( 'category_pagination' ),
                'required' => array( 'category_settings_type', '=', 'custom' ),
            ),

        ),
    ) );

/* Tag */
Redux::setSection( $opt_name ,  array(
        'title'     => esc_html__( 'Tag Templates', 'kobita' ),
        'desc'     => esc_html__( 'Manage settings for your tag templates', 'kobita' ),
        'subsection' => true,
        'fields'    => array(

            array(
                'id'      => 'tag_settings_type',
                'type'    => 'radio',
                'title'   => esc_html__( 'Settings', 'kobita' ),
                'options' => array(
                    'inherit' => esc_html__( 'Inherit from global archive options', 'kobita' ),
                    'custom'  => esc_html__( 'Customize', 'kobita' ),
                ),
                'default' => kobita_get_default_option( 'tag_settings_type' ),

            ),

            array(
                'id' => 'tag_cover',
                'type' => 'switch',
                'title' => esc_html__( 'Display cover', 'kobita' ),
                'subtitle' => esc_html__( 'Check if you want to display cover area on tag templates', 'kobita' ),
                'default' => kobita_get_default_option( 'tag_cover' ),
                'required' => array( 'tag_settings_type', '=', 'custom' ),
            ),

            array(
                'id'        => 'tag_layout',
                'type'      => 'image_select',
                'title'     => esc_html__( 'Main layout', 'kobita' ),
                'subtitle'  => esc_html__( 'Choose your main post layout', 'kobita' ),
                'options'   => kobita_get_main_layouts(),
                'default' => kobita_get_default_option( 'tag_layout' ),
                'required' => array( 'tag_settings_type', '=', 'custom' ),
            ),


            array(
                'id'        => 'tag_ppp',
                'type'      => 'radio',
                'title'     => esc_html__( 'Posts per page', 'kobita' ),
                'subtitle'  => esc_html__( 'Choose how many posts per page you want to display', 'kobita' ),
                'options'   => array(
                    'inherit' => wp_kses( sprintf( __( 'Inherit from global option in <a href="%s">Settings->Reading</a>', 'kobita' ), admin_url( 'options-reading.php' ) ), wp_kses_allowed_html( 'post' ) ),
                    'custom' => esc_html__( 'Custom number', 'kobita' )
                ),
                'default' => kobita_get_default_option( 'tag_ppp' ),
                'required' => array( 'tag_settings_type', '=', 'custom' ),
            ),

            array(
                'id'        => 'tag_ppp_num',
                'type'      => 'text',
                'class'     => 'small-text',
                'title'     => esc_html__( 'Number of posts per page', 'kobita' ),
                'default' => kobita_get_default_option( 'tag_ppp_num' ),
                'validate'  => 'numeric',
                'required' => array(
                    array( 'tag_ppp', '=', 'custom' ),
                    array( 'tag_settings_type', '=', 'custom' )
                ),
            ),

            array(
                'id'        => 'tag_pagination',
                'type'      => 'image_select',
                'title'     => esc_html__( 'Pagination', 'kobita' ),
                'subtitle'  => esc_html__( 'Choose a pagination type for tag templates', 'kobita' ),
                'options'   => kobita_get_pagination_layouts(),
                'default' => kobita_get_default_option( 'tag_pagination' ),
                'required' => array( 'tag_settings_type', '=', 'custom' ),
            ),

        ) )
);

/* Author */
Redux::setSection( $opt_name ,  array(
        'title'     => esc_html__( 'Author Templates', 'kobita' ),
        'desc'     => esc_html__( 'Manage settings for your author templates', 'kobita' ),
        'subsection' => true,
        'fields'    => array(

            array(
                'id'      => 'author_settings_type',
                'type'    => 'radio',
                'title'   => esc_html__( 'Settings', 'kobita' ),
                'options' => array(
                    'inherit' => esc_html__( 'Inherit from global archive options', 'kobita' ),
                    'custom'  => esc_html__( 'Customize', 'kobita' ),
                ),
                'default' => kobita_get_default_option( 'author_settings_type' ),
            ),

            array(
                'id' => 'use_author_image',
                'type' => 'switch',
                'title' => esc_html__( 'Display author avatar on author archive page', 'kobita' ),
                'subtitle' => esc_html__( 'Enable this option if you want to display author avatar/image on author archive page', 'kobita' ),
                'default' => kobita_get_default_option( 'use_author_image' ),
            ),

            array(
                'id' => 'author_cover',
                'type' => 'switch',
                'title' => esc_html__( 'Display cover', 'kobita' ),
                'subtitle' => esc_html__( 'Check if you want to display cover area on author templates', 'kobita' ),
                'default' => kobita_get_default_option( 'author_cover' ),
                'required' => array( 'author_settings_type', '=', 'custom' ),
            ),

            array(
                'id'        => 'author_layout',
                'type'      => 'image_select',
                'title'     => esc_html__( 'Main layout', 'kobita' ),
                'subtitle'  => esc_html__( 'Choose your main post layout', 'kobita' ),
                'options'   => kobita_get_main_layouts(),
                'default' => kobita_get_default_option( 'author_layout' ),
                'required' => array( 'author_settings_type', '=', 'custom' ),
            ),


            array(
                'id'        => 'author_ppp',
                'type'      => 'radio',
                'title'     => esc_html__( 'Posts per page', 'kobita' ),
                'subtitle'  => esc_html__( 'Choose how many posts per page you want to display', 'kobita' ),
                'options'   => array(
                    'inherit' => wp_kses( sprintf( __( 'Inherit from global option in <a href="%s">Settings->Reading</a>', 'kobita' ), admin_url( 'options-reading.php' ) ), wp_kses_allowed_html( 'post' ) ),
                    'custom' => esc_html__( 'Custom number', 'kobita' )
                ),
                'default' => kobita_get_default_option( 'author_ppp' ),
                'required' => array( 'author_settings_type', '=', 'custom' ),
            ),

            array(
                'id'        => 'author_ppp_num',
                'type'      => 'text',
                'class'     => 'small-text',
                'title'     => esc_html__( 'Number of posts per page', 'kobita' ),
                'default' => kobita_get_default_option( 'author_ppp_num' ),
                'validate'  => 'numeric',
                'required'  => array(
                    array( 'author_settings_type', '=', 'custom' ),
                    array( 'author_ppp', '=', 'custom' )
                ),
            ),

            array(
                'id'        => 'author_pagination',
                'type'      => 'image_select',
                'title'     => esc_html__( 'Pagination', 'kobita' ),
                'subtitle'  => esc_html__( 'Choose a pagination type for author templates', 'kobita' ),
                'options'   => kobita_get_pagination_layouts(),
                'default' => kobita_get_default_option( 'author_pagination' ),
                'required' => array( 'author_settings_type', '=', 'custom' ),
            ),
        ) )
);



/* Single Post */
Redux::setSection( $opt_name , array(
        'icon'      => 'el-icon-pencil',
        'title'     => esc_html__( 'Single Post', 'kobita' ),
        'desc'     => esc_html__( 'Manage settings for your single posts', 'kobita' ),
        'fields'    => array(

            array(
                'id' => 'single_cover',
                'type' => 'switch',
                'title' => esc_html__( 'Display cover', 'kobita' ),
                'subtitle' => esc_html__( 'Check if you want to display cover area on single post template', 'kobita' ),
                'default' => kobita_get_default_option( 'single_cover' ),
            ),

            array(
                'id'        => 'single_dropcap',
                'type'      => 'switch',
                'title'     => esc_html__( 'Display dropcap', 'kobita' ),
                'subtitle'  => esc_html__( 'Check if you want to display dropcap (first letter)', 'kobita' ),
                'default' => kobita_get_default_option( 'single_dropcap' ),
            ),

            array(
                'id'        => 'layout_single_meta',
                'type'      => 'sortable',
                'mode'      => 'checkbox',
                'title'     => esc_html__( 'Meta data', 'kobita' ),
                'subtitle'  => esc_html__( 'Check and re-order which meta data you want to display', 'kobita' ),
                'options'   => kobita_get_meta_opts(),
                'default' => kobita_get_default_option( 'layout_single_meta' ),
            ),

            array(
                'id' => 'single_fimg',
                'type' => 'radio',
                'title' => esc_html__( 'Display featured image', 'kobita' ),
                'subtitle' => esc_html__( 'Check if you want to display the featured image', 'kobita' ),
                'options'   => array(
                    'cover' => esc_html__( 'As the post cover background', 'kobita' ),
                    'content' => esc_html__( 'Inside the post content', 'kobita' ),
                    'none' => esc_html__( 'Do not display', 'kobita' ),
                ),
                'default' => kobita_get_default_option( 'single_fimg' ),
            ),

            array(
                'id' => 'single_fimg_cap',
                'type' => 'switch',
                'title' => esc_html__( 'Display featured image caption', 'kobita' ),
                'subtitle' => esc_html__( 'Check if you want to display the caption of the featured image', 'kobita' ),
                'default' => kobita_get_default_option( 'single_fimg_cap' ),
                'required'  => array( 'single_fimg', '=', 'content' )
            ),

            array(
                'id' => 'single_share',
                'type' => 'switch',
                'title' => esc_html__( 'Display share buttons', 'kobita' ),
                'subtitle' => esc_html__( 'Check if you want to display share buttons', 'kobita' ),
                'desc' => !function_exists( 'binarypoets_ess_share' ) ? wp_kses_post( sprintf( __( 'Note: <a href="%s">Meks Easy Social Share plugin</a> must be activated to use this option.', 'kobita' ),  admin_url( 'themes.php?page=install-required-plugins' ) ) ) : '',
                'default' => kobita_get_default_option( 'single_share' ),

            ),

            array(
                'id' => 'single_share_options',
                'type' => 'radio',
                'title' => esc_html__( 'Display share options', 'kobita' ),
                'subtitle' => esc_html__( 'Select where you like to display share buttons', 'kobita' ),
                'desc' => !function_exists( 'binarypoets_ess_share' ) ? wp_kses_post( sprintf( __( 'Note: <a href="%s">Meks Easy Social Share plugin</a> must be activated to use this option.', 'kobita' ),  admin_url( 'themes.php?page=install-required-plugins' ) ) ) : '',
                'options'  => array(
                    'above' => esc_html__( 'Above content', 'kobita' ),
                    'below' => esc_html__( 'Below content', 'kobita' ),
                    'above_below' => esc_html__( 'Above and below content', 'kobita' ),
                ),
                'default' => kobita_get_default_option( 'single_share_options' ),
                'required'  => array( 'single_share', '=', true )
            ),

            array(
                'id' => 'single_tags',
                'type' => 'switch',
                'title' => esc_html__( 'Display tags', 'kobita' ),
                'subtitle' => esc_html__( 'Check if you want to display tags', 'kobita' ),
                'default' => kobita_get_default_option( 'single_tags' ),
            ),

            array(
                'id' => 'single_author',
                'type' => 'switch',
                'title' => esc_html__( 'Display author area', 'kobita' ),
                'subtitle' => esc_html__( 'Check if you want to display the author area', 'kobita' ),
                'default' => kobita_get_default_option( 'single_author' ),
            ),

            array(
                'id' => 'single_sticky_bottom_bar',
                'type' => 'switch',
                'title' => esc_html__( 'Enable sticky bottom bar', 'kobita' ),
                'subtitle' => esc_html__( 'Check if you want to display sticky bottom bar which will appear while you scroll through single posts', 'kobita' ),
                'default' => kobita_get_default_option( 'single_sticky_bottom_bar' ),
            ),

            array(
                'id' => 'single_related',
                'type' => 'switch',
                'title' => esc_html__( 'Display "related" posts', 'kobita' ),
                'subtitle' => esc_html__( 'Choose if you want to display related posts section below single post', 'kobita' ),
                'default' => kobita_get_default_option( 'single_related' ),
            ),

            array(
                'id'        => 'related_type',
                'type'      => 'radio',
                'title'     => esc_html__( 'Related area chooses from posts', 'kobita' ),
                'options'   => array(
                    'cat' => esc_html__( 'Located in the same category', 'kobita' ),
                    'tag' => esc_html__( 'Tagged with at least one same tag', 'kobita' ),
                    'cat_or_tag' => esc_html__( 'Located in the same category OR tagged with a same tag', 'kobita' ),
                    'cat_and_tag' => esc_html__( 'Located in the same category AND tagged with a same tag', 'kobita' ),
                    'author' => esc_html__( 'By the same author', 'kobita' ),
                    '0' => esc_html__( 'All posts', 'kobita' )
                ),
                'default' => kobita_get_default_option( 'related_type' ),
                'required'  => array( 'single_related', '=', true ),
            ),

            array(
                'id'        => 'related_order',
                'type'      => 'radio',
                'title'     => esc_html__( 'Related posts are ordered by', 'kobita' ),
                'options'   => kobita_get_post_order_opts(),
                'default' => kobita_get_default_option( 'related_order' ),
                'required'  => array( 'single_related', '=', true ),
            ),

            array(
                'id'        => 'related_limit',
                'type'      => 'text',
                'class'     => 'small-text',
                'title'     => esc_html__( 'Related area posts number limit', 'kobita' ),
                'default' => kobita_get_default_option( 'related_limit' ),
                'validate'  => 'numeric',
                'required'  => array( 'single_related', '=', true ),
            ),

            array(
                'id'        => 'related_layout',
                'type'      => 'image_select',
                'title'     => esc_html__( 'Related posts layout', 'kobita' ),
                'subtitle'  => esc_html__( 'Choose a layout for related posts', 'kobita' ),
                'options'   => kobita_get_main_layouts(),
                'default' => kobita_get_default_option( 'related_layout' ),
                'required'  => array( 'single_related', '=', true ),
            ),

        ) )
);


/* Page */
Redux::setSection( $opt_name ,  array(
        'icon'      => 'el-icon-file-edit',
        'title'     => esc_html__( 'Page', 'kobita' ),
        'desc'     => esc_html__( 'Manage default settings for your pages', 'kobita' ),
        'fields'    => array(

            array(
                'id' => 'page_cover',
                'type' => 'switch',
                'title' => esc_html__( 'Display cover', 'kobita' ),
                'subtitle' => esc_html__( 'Check if you want to display cover area on pages', 'kobita' ),
                'default' => kobita_get_default_option( 'page_cover' ),
            ),

            array(
                'id'        => 'page_dropcap',
                'type'      => 'switch',
                'title'     => esc_html__( 'Display dropcap', 'kobita' ),
                'subtitle'  => esc_html__( 'Check if you want to display dropcap (first letter)', 'kobita' ),
                'default' => kobita_get_default_option( 'page_dropcap' ),
            ),


            array(
                'id' => 'page_fimg',
                'type' => 'radio',
                'title' => esc_html__( 'Display featured image', 'kobita' ),
                'subtitle' => esc_html__( 'Check if you want to display the featured image', 'kobita' ),
                'options'   => array(
                    'cover' => esc_html__( 'As the post cover background', 'kobita' ),
                    'content' => esc_html__( 'Inside the post content', 'kobita' ),
                    'none' => esc_html__( 'Do not display', 'kobita' ),
                ),
                'default' => kobita_get_default_option( 'page_fimg' ),

            ),

        ) )
);


/* Typography */
Redux::setSection( $opt_name , array(
        'icon'      => 'el-icon-fontsize',
        'title'     => esc_html__( 'Typography', 'kobita' ),
        'desc'     => esc_html__( 'Manage fonts and typography settings', 'kobita' ),
        'fields'    => array(

            array(
                'id'          => 'main_font',
                'type'        => 'typography',
                'title'       => esc_html__( 'Main text font', 'kobita' ),
                'google'      => true,
                'font-backup' => false,
                'font-size' => false,
                'color' => false,
                'line-height' => false,
                'text-align' => false,
                'units'       =>'px',
                'letter-spacing' => true,
                'subtitle'    => esc_html__( 'This is your main font, used for standard text', 'kobita' ),
                'default' => kobita_get_default_option( 'main_font' ),
                'preview' => array(
                    'always_display' => true,
                    'font-size' => '16px',
                    'line-height' => '26px',
                    'text' => 'This is a font used for your main content on the website. Here at Meks, we believe that readability is a very important part of any WordPress theme. This is an example of how a simple paragraph of text will look like on your website.'
                )
            ),

            array(
                'id'          => 'h_font',
                'type'        => 'typography',
                'title'       => esc_html__( 'Headings font', 'kobita' ),
                'google'      => true,
                'font-backup' => false,
                'font-size' => false,
                'color' => false,
                'line-height' => false,
                'text-align' => false,
                'units'       =>'px',
                'letter-spacing' => true,
                'subtitle'    => esc_html__( 'This is a font used for titles and headings', 'kobita' ),
                'default' => kobita_get_default_option( 'h_font' ),
                'preview' => array(
                    'always_display' => true,
                    'font-size' => '35px',
                    'line-height' => '50px',
                    'text' => 'THERE IS NO GOOD BLOG WITHOUT GREAT READABILITY'
                )

            ),

            array(
                'id'          => 'nav_font',
                'type'        => 'typography',
                'title'       => esc_html__( 'Navigation font', 'kobita' ),
                'google'      => true,
                'font-backup' => false,
                'font-size' => false,
                'color' => false,
                'line-height' => false,
                'text-align' => false,
                'units'       =>'px',
                'letter-spacing' => true,
                'subtitle'    => esc_html__( 'This is a font used for main website navigation', 'kobita' ),
                'default' => kobita_get_default_option( 'nav_font' ),
                'preview' => array(
                    'always_display' => true,
                    'font-size' => '11px',
                    'text' => 'HOME &nbsp;&nbsp;ABOUT &nbsp;&nbsp;BLOG &nbsp;&nbsp;CONTACT'
                )

            ),

            array(
                'id'          => 'finetune',
                'type'        => 'section',
                'indent' => false,
                'title'       => esc_html__( 'Fine-tune typography', 'kobita' ),
                'subtitle'    => esc_html__( 'Advanced options to adjust font sizes', 'kobita' )
            ),


            array(
                'id'       => 'font_size_p',
                'type'     => 'spinner',
                'title'    => esc_html__( 'Main text font size', 'kobita' ),
                'subtitle' => esc_html__( 'This is your default text font size', 'kobita' ),
                'default' => kobita_get_default_option( 'font_size_p' ),
                'min'      => '14',
                'step'     => '1',
                'max'      => '22',
            ),

            array(
                'id'       => 'font_size_nav',
                'type'     => 'spinner',
                'title'    => esc_html__( 'Navigation font size', 'kobita' ),
                'subtitle' => esc_html__( 'Applies to main website navigation', 'kobita' ),
                'default' => kobita_get_default_option( 'font_size_nav' ),
                'min'      => '10',
                'step'     => '1',
                'max'      => '20',
            ),


            array(
                'id'       => 'font_size_small',
                'type'     => 'spinner',
                'title'    => esc_html__( 'Small text (widget) font size', 'kobita' ),
                'subtitle' => esc_html__( 'Applies to widgets and some special elements', 'kobita' ),
                'default' => kobita_get_default_option( 'font_size_small' ),
                'min'      => '12',
                'step'     => '1',
                'max'      => '20',
            ),

            array(
                'id'       => 'font_size_meta',
                'type'     => 'spinner',
                'title'    => esc_html__( 'Meta text font size ', 'kobita' ),
                'subtitle' => esc_html__( 'Applies to meta items like author link, date, category link, etc...', 'kobita' ),
                'default' => kobita_get_default_option( 'font_size_meta' ),
                'min'      => '10',
                'step'     => '1',
                'max'      => '18',
            ),

            array(
                'id'       => 'font_size_cover',
                'type'     => 'spinner',
                'title'    => esc_html__( 'Cover title font size', 'kobita' ),
                'subtitle' => esc_html__( 'Applies to cover titles', 'kobita' ),
                'default' => kobita_get_default_option( 'font_size_cover' ),
                'min'      => '50',
                'step'     => '1',
                'max'      => '80',
            ),

            array(
                'id'       => 'font_size_cover_dropcap',
                'type'     => 'spinner',
                'title'    => esc_html__( 'Cover dropcap font size', 'kobita' ),
                'subtitle' => esc_html__( 'Applies to cover background dropcap letter', 'kobita' ),
                'default' => kobita_get_default_option( 'font_size_cover_dropcap' ),
                'min'      => '400',
                'step'     => '1',
                'max'      => '800',
            ),

            array(
                'id'       => 'font_size_dropcap',
                'type'     => 'spinner',
                'title'    => esc_html__( 'Dropcap font size', 'kobita' ),
                'subtitle' => esc_html__( 'Applies to dropcap letter on post/page titles', 'kobita' ),
                'default' => kobita_get_default_option( 'font_size_dropcap' ),
                'min'      => '150',
                'step'     => '1',
                'max'      => '400',
            ),

            array(
                'id'       => 'font_size_h1',
                'type'     => 'spinner',
                'title'    => esc_html__( 'H1 font size', 'kobita' ),
                'subtitle' => esc_html__( 'Applies to H1 elements and single post/page titles', 'kobita' ),
                'default' => kobita_get_default_option( 'font_size_h1' ),
                'min'      => '30',
                'step'     => '1',
                'max'      => '60',
            ),

            array(
                'id'       => 'font_size_h2',
                'type'     => 'spinner',
                'title'    => esc_html__( 'H2 font size', 'kobita' ),
                'subtitle' => esc_html__( 'Applies to H2 elements', 'kobita' ),
                'default' => kobita_get_default_option( 'font_size_h2' ),
                'min'      => '30',
                'step'     => '1',
                'max'      => '55',
            ),

            array(
                'id'       => 'font_size_h3',
                'type'     => 'spinner',
                'title'    => esc_html__( 'H3 font size', 'kobita' ),
                'subtitle' => esc_html__( 'Applies to H3 elements', 'kobita' ),
                'default' => kobita_get_default_option( 'font_size_h3' ),
                'min'      => '25',
                'step'     => '1',
                'max'      => '45',
            ),

            array(
                'id'       => 'font_size_h4',
                'type'     => 'spinner',
                'title'    => esc_html__( 'H4 font size', 'kobita' ),
                'subtitle' => esc_html__( 'Applies to H4 elements', 'kobita' ),
                'default' => kobita_get_default_option( 'font_size_h4' ),
                'min'      => '20',
                'step'     => '1',
                'max'      => '40',
            ),

            array(
                'id'       => 'font_size_h5',
                'type'     => 'spinner',
                'title'    => esc_html__( 'H5 (widget title) font size', 'kobita' ),
                'subtitle' => esc_html__( 'Applies to H5 elements and widget titles', 'kobita' ),
                'default' => kobita_get_default_option( 'font_size_h5' ),
                'min'      => '14',
                'step'     => '1',
                'max'      => '24',
            ),

            array(
                'id'       => 'font_size_h6',
                'type'     => 'spinner',
                'title'    => esc_html__( 'H6 (section title) font size', 'kobita' ),
                'subtitle' => esc_html__( 'Applies to H6 elements and section titles', 'kobita' ),
                'default' => kobita_get_default_option( 'font_size_h6' ),
                'min'      => '14',
                'step'     => '1',
                'max'      => '22',
            ),

            array(
                'id' => 'uppercase',
                'type' => 'checkbox',
                'multi' => true,
                'title' => esc_html__( 'Uppercase text', 'kobita' ),
                'subtitle' => esc_html__( 'Check if you want to show CAPITAL LETTERS for specific elements', 'kobita' ),
                'options' => array(
                    '.site-title' => esc_html__( 'Site title', 'kobita' ),
                    '.kobita-site-description' => esc_html__( 'Site description', 'kobita' ),
                    '.kobita-nav' => esc_html__( 'Main navigation', 'kobita' ),
                    'h1, h2, h3, h4, h5, h6, .wp-block-cover-text, .wp-block-cover-image-text' => esc_html__( 'H elements', 'kobita' ),
                    '.section-title' => esc_html__( 'Section titles', 'kobita' ),
                    '.widget-title' => esc_html__( 'Widget titles', 'kobita' ),
                    '.meta-item' => esc_html__( 'Post meta data', 'kobita' ),
                    '.kobita-button' => esc_html__( 'Buttons', 'kobita' )
                ),
                'default' => kobita_get_default_option( 'uppercase' ),
            ),

            array(
                'id'        => 'content-paragraph-width',
                'type'      => 'slider',
                'title'     => esc_html__( 'Content paragraph width', 'kobita' ),
                'subtitle'  => esc_html__( 'Width of paragraph will be applied to single post, page and Layout A', 'kobita' ),
                'default' => kobita_get_default_option( 'content-paragraph-width' ),
                'min'       => 600,
                'step'      => 5,
                'max'       => 800,
                'display_value' => 'label'
            ),

        ) )
);



/* Ads */
Redux::setSection( $opt_name , array(
        'icon'      => 'el-icon-usd',
        'title'     => esc_html__( 'Ads', 'kobita' ),
        'desc'     => esc_html__( 'Use these options to fill your ad slots. Both image and JavaScript related ads are allowed.', 'kobita' ),
        'fields'    => array(

            array(
                'id' => 'ad_top',
                'type' => 'editor',
                'title' => esc_html__( 'Top', 'kobita' ),
                'subtitle' => esc_html__( 'This ad will be displayed above the content', 'kobita' ),
                'default' => kobita_get_default_option( 'ad_top' ),
                'desc' => esc_html__( 'Note: If you want to paste an HTML or a JavaScript code, use "text" mode in editor', 'kobita' ),
                'args'   => array(
                    'textarea_rows'    => 5,
                    'default_editor' => 'html'
                )
            ),

            array(
                'id' => 'ad_bottom',
                'type' => 'editor',
                'title' => esc_html__( 'Bottom', 'kobita' ),
                'subtitle' => esc_html__( 'This ad will be displayed below the content', 'kobita' ),
                'default' => kobita_get_default_option( 'ad_bottom' ),
                'desc' => esc_html__( 'Note: If you want to paste an HTML or a JavaScript code, use "text" mode in editor', 'kobita' ),
                'args'   => array(
                    'textarea_rows'    => 5,
                    'default_editor' => 'html'
                )
            ),

            array(
                'id' => 'ad_between_posts',
                'type' => 'editor',
                'title' => esc_html__( 'Between posts', 'kobita' ),
                'subtitle' => esc_html__( 'This ad will be displayed between posts. You can specify the position in the option below.', 'kobita' ),
                'default' => kobita_get_default_option( 'ad_between_posts' ),
                'desc' => esc_html__( 'Note: If you want to paste an HTML or a JavaScript code, use "text" mode in editor', 'kobita' ),
                'args'   => array(
                    'textarea_rows'    => 5,
                    'default_editor' => 'html'
                )
            ),


            array(
                'id' => 'ad_between_posts_position',
                'type' => 'text',
                'class' => 'small-text',
                'title' => esc_html__( 'Between posts position', 'kobita' ),
                'subtitle' => esc_html__( 'Specify after how many posts you want to display the ad', 'kobita' ),
                'validate' => 'numeric',
                'default' => kobita_get_default_option( 'ad_between_posts_position' ),
            ),

            array(
                'id'       => 'ad_exclude_404',
                'type'     => 'switch',
                'title'    => esc_html__( 'Do not show ads on 404 page', 'kobita' ),
                'subtitle' => esc_html__( 'Disable ads on 404 error page', 'kobita' ),
                'default' => kobita_get_default_option( 'ad_exclude_404' ),
            ),

            array(
                'id'       => 'ad_exclude_from_pages',
                'type'     => 'select',
                'title'    => esc_html__( 'Do not show ads on specific pages', 'kobita' ),
                'subtitle' => esc_html__( 'Select pages on which you don\'t want to display ads', 'kobita' ),
                'multi'    => true,
                'sortable' => true,
                'data'     => 'page',
                'args'     => array(
                    'posts_per_page' => - 1,
                ),
                'default' => kobita_get_default_option( 'ad_exclude_from_pages' ),
            ),
        )
    )
);


/* Misc. */
Redux::setSection( $opt_name , array(
        'icon'      => 'el-icon-wrench',
        'title'     => esc_html__( 'Misc.', 'kobita' ),
        'desc'     => esc_html__( 'These are some additional miscellaneous theme settings', 'kobita' ),
        'fields'    => array(

            array(
                'id' => 'rtl_mode',
                'type' => 'switch',
                'title' => esc_html__( 'RTL mode (right to left)', 'kobita' ),
                'subtitle' => esc_html__( 'Enable this option if you are using right to left writing/reading', 'kobita' ),
                'default' => kobita_get_default_option( 'rtl_mode' ),
            ),

            array(
                'id' => 'rtl_lang_skip',
                'type' => 'text',
                'title' => esc_html__( 'Skip RTL for specific language(s)', 'kobita' ),
                'subtitle' => esc_html__( 'Paste specific WordPress language <a href="http://wpcentral.io/internationalization/" target="_blank">locale code</a> to exclude it from the RTL mode', 'kobita' ),
                'desc' => esc_html__( 'i.e. If you are using Arabic and English versions on the same WordPress installation you should put "en_US" in this field and its version will not be displayed as RTL. Note: To exclude multiple languages, separate by comma: en_US, de_DE', 'kobita' ),
                'default' => kobita_get_default_option( 'rtl_lang_skip' ),
                'required' => array( 'rtl_mode', '=', true )
            ),


            array(
                'id' => 'more_string',
                'type' => 'text',
                'class' => 'small-text',
                'title' => esc_html__( 'More string', 'kobita' ),
                'subtitle' => esc_html__( 'Specify your "more" string to append after limited post excerpts', 'kobita' ),
                'default' => kobita_get_default_option( 'more_string' ),
                'validate' => 'no_html'
            ),

            array(
                'id' => 'use_gallery',
                'type' => 'switch',
                'title' => esc_html__( 'Use built-in theme gallery', 'kobita' ),
                'subtitle' => esc_html__( 'Enable this option if you want to use built-in theme gallery style, or disable if you are using some other gallery plugin to avoid conflicts', 'kobita' ),
                'default' => kobita_get_default_option( 'use_gallery' ),
            ),

            array(
                'id' => 'scroll_down_arrow',
                'type' => 'switch',
                'title' => esc_html__( 'Display scroll-down arrow in cover', 'kobita' ),
                'subtitle' => esc_html__( 'Use this option if you want to display an arrow as a scrolling indicator', 'kobita' ),
                'desc' => esc_html__( 'Note: The arrow will be visible on smaller resolutions only (if cover area fills the entire screen)', 'kobita' ),
                'default' => kobita_get_default_option( 'scroll_down_arrow' ),
            ),

            array(
                'id' => 'words_read_per_minute',
                'type' => 'text',
                'class' => 'small-text',
                'title' => esc_html__( 'Words to read per minute', 'kobita' ),
                'subtitle' => esc_html__( 'Use this option to set number of words your visitors read per minute, in order to fine-tune calculation of post reading time meta data', 'kobita' ),
                'validate' => 'numeric',
                'default' => kobita_get_default_option( 'words_read_per_minute' ),
            ),

            array(
				'id'       => 'post_modified_date',
				'type'     => 'switch',
				'title' => esc_html__( 'Use "last modified" date for post meta data', 'kobita' ),
				'subtitle' => esc_html__( 'Enable this option if you want posts to display modified date instead of publish date.', 'kobita' ),
				'default' => kobita_get_default_option( 'post_modified_date' )
			)

        )
    )
);


Redux::setSection( $opt_name , array(
        'type' => 'divide',
        'id' => 'kobita-divide',
    ) );

/* Translation Options */

$translate_options[] = array(
    'id' => 'enable_translate',
    'type' => 'switch',
    'switch' => true,
    'title' => esc_html__( 'Enable theme translation?', 'kobita' ),
    'default' => kobita_get_default_option( 'enable_translate' ),
);

$translate_strings = kobita_get_translate_options();

foreach ( $translate_strings as $string_key => $string ) {
    $translate_options[] = array(
        'id' => 'tr_'.$string_key,
        'type' => 'text',
        'title' => esc_html( $string['text'] ),
        'subtitle' => isset( $string['desc'] ) ? $string['desc'] : '',
        'default' => ''
    );
}

Redux::setSection( $opt_name, array(
        'icon'      => 'el-icon-globe-alt',
        'title' => esc_html__( 'Translation', 'kobita' ),
        'desc' => wp_kses_post( __( 'Use these settings to quckly translate or change the text in this theme. If you want to remove the text completely instead of modifying it, you can use <strong>"-1"</strong> as a value for particular field translation. <br/><br/><strong>Note:</strong> If you are using this theme for a multilingual website, you need to disable these options and use multilanguage plugins (such as WPML) and manual translation with .po and .mo files located inside the "languages" folder.', 'kobita' ) ),
        'fields' => $translate_options
    ) );

/* Performance */
Redux::setSection( $opt_name , array(
        'icon'      => 'el-icon-dashboard',
        'title'     => esc_html__( 'Performance', 'kobita' ),
        'desc'     => esc_html__( 'Use these options to put your theme to a high speed as well as save your server resources!', 'kobita' ),
        'fields'    => array(

            array(
                'id' => 'minify_css',
                'type' => 'switch',
                'title' => esc_html__( 'Use minified CSS', 'kobita' ),
                'subtitle' => esc_html__( 'Load all theme css files combined and minified into a single file.', 'kobita' ),
                'default' => kobita_get_default_option( 'minify_css' ),
            ),

            array(
                'id' => 'minify_js',
                'type' => 'switch',
                'title' => esc_html__( 'Use minified JS', 'kobita' ),
                'subtitle' => esc_html__( 'Load all theme js files combined and minified into a single file.', 'kobita' ),
                'default' => kobita_get_default_option( 'minify_js' ),
            ),

            array(
                'id' => 'disable_img_sizes',
                'type' => 'checkbox',
                'multi' => true,
                'title' => esc_html__( 'Disable additional image sizes', 'kobita' ),
                'subtitle' => esc_html__( 'By default, theme generates additional image size for each of the layouts it offers. You can use this option to avoid creating additional sizes if you are not using particular layout in order to save your server space.', 'kobita' ),
                'options' => array(
                    'cover' => esc_html__( 'Cover image', 'kobita' ),
                    'a' => esc_html__( 'Layout A image (also used for single post and pages)', 'kobita' ),
                    'b' => esc_html__( 'Layout B image', 'kobita' ),
                    'c' => esc_html__( 'Layout C image', 'kobita' ),
                ),
                'default' => kobita_get_default_option( 'disable_img_sizes' ),
            ),



        ) ) );


?>
