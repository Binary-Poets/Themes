<?php

/**
 * Load page metaboxes
 *
 * Callback function for page metaboxes load
 * @since 1.5
 */
if (!function_exists('kobita_load_metaboxes')) :
	function kobita_load_metaboxes() {
		
		/* Display settings metabox */
		add_meta_box(
			'kobita_display_settings',
			esc_html__('Display settings', 'kobita'),
			'kobita_display_settings_metabox',
			array('page', 'post'),
			'side',
			'default'
		
		);
	}
endif;



/**
 * Save post meta
 *
 * Callback function to save post meta data
 *
 * @since  1.5
 */

if ( !function_exists( 'kobita_save_metaboxes' ) ) :
	function kobita_save_metaboxes( $post_id, $post ) {
		
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
			return;
		
		if ( !isset( $_POST['kobita_post_metabox_nonce'] ) || !wp_verify_nonce( $_POST['kobita_post_metabox_nonce'], 'kobita_post_metabox_save' ) ) {
			return;
		}
		
		if ( ($post->post_type == 'post' || $post->post_type == 'page') && isset( $_POST['kobita'] ) ) {
			$post_type = get_post_type_object( $post->post_type );
			if ( !current_user_can( $post_type->cap->edit_post, $post_id ) )
				return $post_id;
			
			$kobita_meta = array();
			
			if( isset( $_POST['kobita']['display_settings'] ) ){
				$kobita_meta['display_settings'] = $_POST['kobita']['display_settings'];
				
				if( $_POST['kobita']['display_settings'] == 'custom' ){
					
					if( isset( $_POST['kobita']['cover'] ) ){
						$kobita_meta['cover'] = $_POST['kobita']['cover'];
					}
					if( isset( $_POST['kobita']['fimg'] ) ){
						$kobita_meta['fimg'] = $_POST['kobita']['fimg'];
					}
					
				}
				
			}
			
			if(!empty($kobita_meta)){
				update_post_meta( $post_id, '_kobita_meta', $kobita_meta );
			} else {
				delete_post_meta( $post_id, '_kobita_meta');
			}
			
		}
	}
endif;

/**
 * Layout metabox
 *
 * Callback function to create layout metabox
 *
 * @since  1.5
 */

if ( !function_exists( 'kobita_display_settings_metabox' ) ) :
	function kobita_display_settings_metabox( $object ) {
		wp_nonce_field( 'kobita_post_metabox_save', 'kobita_post_metabox_nonce' );
		
		if(function_exists('kobita_get_' . $object->post_type . '_meta')){
			$meta = call_user_func('kobita_get_' . $object->post_type . '_meta', $object->ID);
		}
		
		if(empty($meta)){
		    return false;
		}
		
		?>
		<label>
			<input type="radio" class="kobita-display-settings"  name="kobita[display_settings]" value="inherit" <?php checked($meta['display_settings'], 'inherit'); ?>>
			<?php esc_html_e( 'Inherit from theme options', 'kobita' ); ?>
		</label>
		<br>
		<label>
			<input type="radio" class="kobita-display-settings" name="kobita[display_settings]" value="custom" <?php checked($meta['display_settings'], 'custom'); ?>>
			<?php esc_html_e( 'Customize', 'kobita' ); ?>
		</label>
		
		<div class="kobita-watch-for-changes" data-watch="kobita-display-settings" data-hide-on-value="inherit">
			<label>
				<input type="hidden" name="kobita[cover]" value="0">
				<h4><input type="checkbox" name="kobita[cover]" value="1" <?php checked($meta['cover'], 1); ?>> <?php esc_html_e( 'Display cover', 'kobita' ); ?></h4>
			</label>
		</div>
		
		<div class="kobita-watch-for-changes" data-watch="kobita-display-settings" data-hide-on-value="inherit">
			<h4><?php esc_html_e('Display featured image', 'kobita') ?></h4>
			<label>
				<input type="radio" name="kobita[fimg]" value="cover" <?php checked($meta['fimg'], 'cover'); ?>>
				<?php esc_html_e('As the post cover background', 'kobita'); ?>
				<br>
			</label>
			<label>
				<input type="radio" name="kobita[fimg]" value="content" <?php checked($meta['fimg'], 'content'); ?>>
				<?php esc_html_e('Inside the post content', 'kobita'); ?>
				<br>
			</label>
			<label>
				<input type="radio" name="kobita[fimg]" value="none" <?php checked($meta['fimg'], 'none'); ?>>
				<?php esc_html_e('Do not display', 'kobita'); ?>
			</label>
		</div>
		<?php
	}
endif;

