<?php

/* Load frontend scripts and styles */
add_action( 'wp_enqueue_scripts', 'kobita_load_scripts' );

/**
 * Load scripts and styles on frontend
 *
 * It just wraps two other separate functions for loading css and js files
 *
 * @since  1.0
 */

function kobita_load_scripts() {
	kobita_load_css();
	kobita_load_js();
}

/**
 * Load frontend css files
 *
 * @since  1.0
 */

function kobita_load_css() {

	//Load google fonts
	if ( $fonts_link = kobita_generate_fonts_link() ) {
		wp_enqueue_style( 'kobita-fonts', $fonts_link, false, KOBITA_THEME_VERSION );
	}

	//Check if is minified option active and load appropriate files
	if ( kobita_get_option( 'minify_css' ) ) {

		wp_enqueue_style( 'kobita-main', get_parent_theme_file_uri( '/assets/css/min.css' ), false, KOBITA_THEME_VERSION );

	} else {

		$styles = array(
			'font-awesome' => 'font-awesome.css',
			'normalize' => 'normalize.css',
			'magnific-popup' => 'magnific-popup.css',
			'owl-carousel' => 'owl-carousel.css',
			'main' => 'main.css'
		);

		foreach ( $styles as $id => $style ) {
			wp_enqueue_style( 'kobita-' . $id, get_parent_theme_file_uri( '/assets/css/' . $style ), false, KOBITA_THEME_VERSION );
		}
	}

	//Append dynamic css
	wp_add_inline_style( 'kobita-main', kobita_generate_dynamic_css() );


	//Load RTL css
	if ( kobita_is_rtl() ) {
		wp_enqueue_style( 'kobita-rtl', get_parent_theme_file_uri( '/assets/css/rtl.css' ), array( 'kobita-main' ), KOBITA_THEME_VERSION );
	}

	//Load WooCommerce css
	if ( kobita_is_woocommerce_active() ) {
		wp_enqueue_style( 'kobita-woocommerce', get_parent_theme_file_uri( '/assets/css/kobita-woocommerce.css' ), array( 'kobita-main' ), KOBITA_THEME_VERSION );
	}

	//Do not load font awesome from our shortcodes plugin
	wp_dequeue_style( 'binarypoets_shortcodes_fntawsm_css' );

}


/**
 * Load frontend js files
 *
 * @since  1.0
 */

function kobita_load_js() {

	//Load comment reply js
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}

	//Check if is minified option active and load appropriate files
	if ( kobita_get_option( 'minify_js' ) ) {

		wp_enqueue_script( 'kobita-main', get_parent_theme_file_uri( '/assets/js/min.js' ), array( 'jquery', 'imagesloaded' ), KOBITA_THEME_VERSION, true );

	} else {

		$scripts = array(
			'magnific-popup' => 'magnific-popup.js',
			'fitvids' => 'fitvids.js',
			'owl-carousel' => 'owl-carousel.js',
			'main' => 'main.js'
		);

		foreach ( $scripts as $id => $script ) {
			wp_enqueue_script( 'kobita-'.$id, get_parent_theme_file_uri( '/assets/js/'. $script ), array( 'jquery', 'imagesloaded' ), KOBITA_THEME_VERSION, true );
		}
	}

	wp_localize_script( 'kobita-main', 'kobita_js_settings', kobita_get_js_settings() );
}
?>
