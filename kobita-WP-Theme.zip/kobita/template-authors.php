<?php
/**
 * Template Name: Authors
 */ 
?>

<?php get_header(); ?>

	<?php if( have_posts() ): ?>
		
		<?php while( have_posts() ) : the_post(); ?>
		
		<?php $meta = kobita_get_page_meta(); ?>
        
        <?php $cover_class = !absint($meta['cover']) ? 'kobita-cover-empty' : ''; ?>
        
        <div id="kobita-cover" class="kobita-cover <?php echo esc_attr($cover_class); ?>">
            
            <?php if(absint($meta['cover'])): ?>
	            
                <?php get_template_part('template-parts/cover/cover-page'); ?>
	            
                <?php if(kobita_get_option( 'scroll_down_arrow' )): ?>
                    <a href="javascript:void(0)" class="kobita-scroll-down-arrow"><i class="fa fa-angle-down"></i></a>
	            <?php endif; ?>

            <?php endif; ?>

        </div>
        
        <div class="kobita-fake-bg">
            
            <div class="kobita-section">
                
                <?php get_template_part('template-parts/ads/top'); ?>

                <div class="section-content section-content-page">

                    <article id="post-<?php the_ID(); ?>" <?php post_class( 'kobita-post kobita-single-post' ); ?>>
                        
                        <?php if(!absint($meta['cover']) ) : ?>

                            <header class="entry-header">
                                <?php the_title( '<h1 class="entry-title entry-title-cover-empty">', '</h1>' ); ?>
                                <?php if( kobita_get_option( 'page_dropcap' ) ) : ?>
                                        <div class="post-letter"><?php echo kobita_get_letter(); ?></div>
                                <?php endif; ?>
                            </header>

                        <?php endif; ?>

                        <div class="entry-content clearfix">

                            <?php if( $meta['fimg'] == 'content' && has_post_thumbnail() ) : ?>
                                <div class="kobita-featured-image">
                                    <?php the_post_thumbnail('kobita-a'); ?>
                                </div>
                            <?php endif; ?>

                            <?php the_content(); ?>

                            <?php $authors = kobita_get_authors(); ?>
                           
                            <?php if ( ! empty( $authors ) ) :?>
                                
                                <?php foreach ($authors as $author) : ?>

                                    <div class="kobita-author">
                                            
                                        <div class="container">

                                            <div class="col-lg-2">
                                                <?php echo get_avatar( get_the_author_meta( 'ID', $author->ID), 100); ?>
                                            </div>

                                            <div class="col-lg-10">

                                                <?php echo '<h5 class="kobita-author-box-title">'.get_the_author_meta('display_name', $author->ID).'</h5>'; ?>

                                                <div class="kobita-author-desc">
                                                    <?php echo wpautop( get_the_author_meta('description', $author->ID) ); ?>
                                                </div>

                                                <div class="kobita-author-links">
                                                    <?php echo kobita_get_author_links( $author->ID ); ?>
                                                </div>

                                            </div>

                                        </div>

                                    </div>

                                <?php endforeach; ?>

                            <?php endif; ?>

                        </div>

                    </article>

                </div>

                <?php get_template_part('template-parts/ads/bottom'); ?>

            </div>

		<?php endwhile; ?>

	<?php endif; ?>

<?php get_footer(); ?>