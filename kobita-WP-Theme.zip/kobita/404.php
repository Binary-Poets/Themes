<?php get_header(); ?>

<div id="kobita-cover" class="kobita-cover kobita-cover-empty"></div>

<div class="kobita-fake-bg">
	
	<div class="kobita-section">
		<?php get_template_part('template-parts/ads/top'); ?>
		
		<div class="section-content">
			
			<article <?php post_class( 'kobita-post' ); ?>>

		        <header class="entry-header">
		            <h1><?php echo esc_html( __kobita( '404_title') ); ?></h1>
		            <div class="post-letter"><?php echo kobita_get_letter( esc_html( __kobita( '404_title') ) ); ?></div>
		        </header>
		        
		        <div class="entry-content">
		            <p><?php echo esc_html( __kobita( '404_text') ); ?></p>
		            <?php get_search_form(); ?>
		        </div>

	    	</article>

		</div>
		
		<?php get_template_part('template-parts/ads/bottom'); ?>
	</div>

<?php get_footer(); ?>