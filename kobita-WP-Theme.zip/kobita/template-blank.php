<?php
/**
 * Template Name: Blank
 */
?>

<?php get_header(); ?>

<?php if( have_posts() ): ?>
    
    <?php while( have_posts() ) : the_post(); ?>
        
        <div id="kobita-cover" class="kobita-cover kobita-cover-empty"></div>
  
        <div class="kobita-fake-bg">

            <div class="kobita-section">
                
                <div class="section-content section-content-page">
                    
                    <article id="post-<?php the_ID(); ?>" <?php post_class( 'kobita-post kobita-single-post' ); ?>>
                    
                        <div class="entry-content clearfix">
                            <?php the_content(); ?>
                        </div>
                    
                    </article>
                
                </div>
                
            </div>
    
    <?php endwhile; ?>

<?php endif; ?>

<?php get_footer(); ?>