<article <?php post_class( 'kobita-post kobita-layout-b ' . esc_attr($ad_class) ); ?>>

    <header class="entry-header">
        <div class="post-date-hidden"><?php echo get_the_date(); ?></div>
        <?php the_title( sprintf( '<h2 class="entry-title"><a href="%s">', esc_url( get_permalink() ) ), '</a></h2>' ); ?>
         <?php if( $meta = kobita_meta_display('b') ) : ?> 
            <div class="entry-meta"><?php echo kobita_get_meta_data( $meta ); ?></div>
        <?php endif; ?>
        <?php $date = the_date('d', '', '', false ); ?>
        <div class="post-date">
            <?php if( !empty( $date  ) ) : ?>
                <span class="post-date-day"><?php echo get_the_date( 'd' ); ?></span><span class="post-date-month"><?php echo get_the_date( 'F' ); ?></span>
            <?php endif; ?>
        </div>
    </header>

    <div class="entry-content">
        <?php if( kobita_get_option( 'layout_b_fimg' ) && has_post_thumbnail() ) : ?>
            <a href="<?php the_permalink(); ?>" class="kobita-featured-image"><?php the_post_thumbnail('kobita-b'); ?></a>
        <?php endif; ?>
        <?php if( kobita_get_option('layout_b_excerpt') ) : ?>
            <?php echo kobita_get_excerpt( kobita_get_option( 'layout_b_excerpt_limit' ) ); ?>
        <?php endif; ?>
    </div>
    <?php if( $buttons = kobita_buttons_display('b') ) : ?>      
        <div class="entry-footer">
            <?php echo kobita_get_buttons_data( $buttons ); ?>
        </div>
    <?php endif; ?>

</article>