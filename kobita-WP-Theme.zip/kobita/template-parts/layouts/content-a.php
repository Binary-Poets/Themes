<article <?php post_class( 'kobita-post kobita-layout-a ' . esc_attr($ad_class) ); ?>>

    <header class="entry-header">
        <?php the_title( sprintf( '<h2 class="entry-title h1"><a href="%s">', esc_url( get_permalink() ) ), '</a></h2>' ); ?>
        <?php if( $meta = kobita_meta_display('a') ) : ?> 
            <div class="entry-meta"><?php echo kobita_get_meta_data( $meta ); ?></div>
        <?php endif; ?>
        <?php if( kobita_get_option( 'layout_a_dropcap' ) ) : ?>
            <div class="post-letter"><?php echo kobita_get_letter(); ?></div>
        <?php endif; ?>
    </header>

    <div class="entry-content">
        <?php if( kobita_get_option( 'layout_a_fimg' ) && has_post_thumbnail() ) : ?>
            <a href="<?php the_permalink(); ?>" class="kobita-featured-image"><?php the_post_thumbnail('kobita-a'); ?></a>
        <?php endif; ?>

        <?php if( kobita_get_option('layout_a_content') == 'excerpt' ) : ?>
            <?php echo kobita_get_excerpt( kobita_get_option( 'layout_a_excerpt_limit' ) ); ?>
        <?php else: ?>
            <?php the_content(); ?>
        <?php endif; ?>
    </div>
    
    <?php if( $buttons = kobita_buttons_display('a') ) : ?>      
        <div class="entry-footer">
            <?php echo kobita_get_buttons_data( $buttons ); ?>
        </div>
    <?php endif; ?>

</article>