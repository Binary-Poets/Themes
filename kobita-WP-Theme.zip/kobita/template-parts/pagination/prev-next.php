<div class="kobita-pagination">
	<nav class="navigation prev-next">
		<div class="prev"><?php previous_posts_link( __kobita( 'newer_entries' ) ); ?></div>
		<div class="next"><?php next_posts_link( __kobita( 'older_entries' ) ); ?></div>
	</nav>
</div>