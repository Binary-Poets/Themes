<?php if( kobita_get_option('single_sticky_bottom_bar') ) : ?>
	<div id="kobita-single-sticky" class="kobita-single-sticky">
		
		<div class="kobita-sticky-content meta">
			<?php get_template_part('template-parts/single/sticky-meta'); ?>
		</div>

		<div class="kobita-sticky-content prev-next">
			<?php get_template_part('template-parts/single/sticky-prev-next'); ?>
		</div>
	</div>
<?php endif; ?>