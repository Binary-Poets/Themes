
<div class="kobita-flex-center">
	<div class="kobita-sticky-author kobita-sticky-l">

		<?php if( kobita_is_co_authors_active() && $coauthors_meta = get_coauthors() ) : ?>
			<?php 
				$co_authors = array();
				foreach ($coauthors_meta as $key ) {
					$co_authors[] = '<a href="'. esc_url(  get_author_posts_url( $key->ID, $key->user_nicename ) ).'">'. esc_html($key->display_name).'</a>';
				} 
			?>
			<span class="sticky-author-title">
				<?php echo __kobita( 'by' ) .' '. implode(', ', $co_authors); ?>
				<span class="sticky-author-date"><?php echo get_the_date(); ?></span>
			</span>

		<?php else: ?>

			<?php echo get_avatar( get_the_author_meta('ID'), 50); ?>
			<span class="sticky-author-title">
				<a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta('ID') ) ); ?>"><?php echo __kobita( 'by' ) . ' ' . get_the_author_meta('display_name'); ?></a>
				<span class="sticky-author-date"><?php echo get_the_date(); ?></span>
			</span>

		<?php endif; ?>
	</div>

	<div class="kobita-sticky-c">
		
	</div>

	<div class="kobita-sticky-comments kobita-sticky-r">
		<?php if ( comments_open() || get_comments_number() ) : ?>
					<?php 
						$icon = '<i class="fa fa-comments-o"></i>';
						comments_popup_link( $icon.__kobita( 'no_comments' ), $icon.__kobita( 'one_comment' ), $icon.__kobita( 'multiple_comments' ) ); 
					?>
		<?php endif; ?>
	</div>

</div>
