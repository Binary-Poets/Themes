<?php if( kobita_get_option( 'single_author' ) ): ?>

	<?php kobita_section_heading( array( 'title' => __kobita('about_author') ) ); ?>
	
	<?php if( kobita_is_co_authors_active() && $coauthors_meta = get_coauthors() ) : ?>
		
		<div class="section-content kobita-author kobita-co-author-section">
	
			<?php foreach ($coauthors_meta as $key ) :  ?>
					
				<div class="container">

					<div class="col-lg-2">
						<?php echo get_avatar( $key->ID, 100 ); ?>
					</div>

					<div class="col-lg-10">

						<?php echo '<h5 class="kobita-author-box-title">'. esc_html( $key->display_name ).'</h5>'; ?>

						<div class="kobita-author-desc">
							<?php echo wpautop(  $key->description ); ?>
						</div>

						<div class="kobita-author-links">
							<?php echo kobita_get_author_links( $key->ID ); ?>
						</div>

					</div>

				</div>

			<?php endforeach; ?>
		</div>
		
	<?php else: ?>

		<div class="section-content kobita-author">
				
			<div class="container">

				<div class="col-lg-2">
					<?php echo get_avatar( get_the_author_meta('ID'), 100); ?>
				</div>

				<div class="col-lg-10">

					<?php echo '<h5 class="kobita-author-box-title">'.get_the_author_meta('display_name').'</h5>'; ?>

					<div class="kobita-author-desc">
						<?php echo wpautop( get_the_author_meta('description') ); ?>
					</div>

					<div class="kobita-author-links">
						<?php echo kobita_get_author_links( get_the_author_meta('ID') ); ?>
					</div>

				</div>

			</div>

		</div>

	<?php endif; ?>
		

<?php endif; ?>