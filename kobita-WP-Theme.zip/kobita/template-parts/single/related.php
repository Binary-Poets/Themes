<?php if( kobita_get_option( 'single_related' ) ): ?>

	<?php $related_query = kobita_get_related_posts(); ?>

	<?php if( $related_query->have_posts() ) : ?>

		<div class="kobita-section kobita-section-related">

			<?php kobita_section_heading( array( 'title' => __kobita('related') ) ); ?>

			<?php $related_layout = kobita_get_option( 'related_layout'); ?>

			<div class="section-content section-content-<?php echo esc_attr( $related_layout ); ?>">

				<div class="kobita-posts">

					<?php while( $related_query->have_posts() ) : $related_query->the_post(); ?>
						<?php get_template_part('template-parts/layouts/content-' . $related_layout ); ?>
					<?php endwhile; ?>
				
				</div>
			</div>
		
		</div>

	<?php endif; ?>

	<?php wp_reset_postdata(); ?>

<?php endif; ?>