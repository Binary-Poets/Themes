<div class="kobita-site-branding">
	
	<?php echo kobita_get_branding(); ?>
	<?php get_template_part('template-parts/header/elements/site-desc'); ?>

</div>
