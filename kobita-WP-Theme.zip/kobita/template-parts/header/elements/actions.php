<ul class="kobita-nav kobita-actions-list">
    <?php
    $elements = kobita_get_header_elements();
    foreach ($elements as $element) {
        get_template_part('template-parts/header/elements/' . $element);
    } ?>
</ul>