<div class="kobita-ad kobita-ad-between-posts"><?php echo do_shortcode( kobita_get_option( 'ad_between_posts' ) ); ?></div>
