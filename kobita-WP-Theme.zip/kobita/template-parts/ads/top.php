<?php if( kobita_can_display_ads() && $ad = kobita_get_option('ad_top') ): ?>
    <div class="kobita-ad kobita-ad-top"><?php echo do_shortcode( $ad ); ?></div>
<?php endif; ?>
    