(function($) {

    "use strict";

    var WatchForChanges = {

        init: function() {
            var $watchers = $('.kobita-watch-for-changes');

            if (kobita_empty($watchers)) {
                return;
            }

            $watchers.each(this.initWatching);
        },

        initWatching: function(i, elem) {
            var $elem = $(elem),
                watchedElemClass = $elem.data('watch'),
                forValue = $elem.data('hide-on-value');

            $('body').on('change', '.' + watchedElemClass, hideByValue);

            function hideByValue() {
                var $this = $(this);

                if (!$this.hasClass(watchedElemClass)) {
                    $this = $('.' + watchedElemClass + ':checked, ' + '.' + watchedElemClass + ':checked');
                }

                if (kobita_empty($this)) {
                    return false;
                }

                var val = $this.val();

                if (val === forValue) {
                    $elem.slideUp('fast');
                    return true;
                }

                $elem.slideDown('fast');
                return false;
            }

            hideByValue();
        }

    };


    $(document).ready(function() {

        $('body').on('click', 'img.kobita-img-select', function(e) {
            e.preventDefault();
            $(this).closest('ul').find('img.kobita-img-select').removeClass('selected');
            $(this).addClass('selected');
            $(this).closest('ul').find('input').removeAttr('checked');
            $(this).closest('li').find('input').attr('checked', 'checked');
        });

        WatchForChanges.init();


        $("body").on('click', '#kobita_welcome_box_hide', function(e) {
            e.preventDefault();
            $(this).parent().fadeOut(300).remove();
            $.post(ajaxurl, { action: 'kobita_hide_welcome' }, function(response) {});
        });

        $("body").on('click', '#kobita_update_box_hide', function(e) {
            e.preventDefault();
            $(this).parent().remove();
            $.post(ajaxurl, { action: 'kobita_update_version' }, function(response) {});
        });

        $('body').on('click', '.binarypoets-twitter-share-button', function(e) {
            e.preventDefault();
            var data = $(this).attr('data-url');
            kobita_social_share(data);
        });



        $('.kobita-redux-marker').each(function() {
            var elem = $(this);
            elem.parents('tr:first').css({ display: 'none' }).prev('tr').css('border-bottom', 'none');
            var group = elem.parents('.redux-group-tab:first');
            if (!group.hasClass('sectionsChecked')) {
                group.addClass('sectionsChecked');
                var test = group.find('.redux-section-indent-start h3');
                jQuery.each(
                    test,
                    function(key, value) {
                        jQuery(value).css('margin-top', '20px');
                    }
                );

                if (group.find('h3:first').css('margin-top') == "20px") {
                    group.find('h3:first').css('margin-top', '0');
                }
            }

        });

    }); // end document ready

    function kobita_social_share(data) {
        window.open(data, "Share", 'height=500,width=760,top=' + ($(window).height() / 2 - 250) + ', left=' + ($(window).width() / 2 - 380) + 'resizable=0,toolbar=0,menubar=0,status=0,location=0,scrollbars=0');
    }

    /**
     * Checks if variable is empty or not
     *
     * @param variable
     * @returns {boolean}
     */
    function kobita_empty(variable) {

        if (typeof variable === 'undefined') {
            return true;
        }

        if (variable === 0 || variable === '0') {
            return true;
        }

        if (variable === null) {
            return true;
        }

        if (variable.length === 0) {
            return true;
        }

        if (variable === "") {
            return true;
        }

        if (variable === false) {
            return true;
        }

        if (typeof variable === 'object' && $.isEmptyObject(variable)) {
            return true;
        }

        return false;
    }

})(jQuery);