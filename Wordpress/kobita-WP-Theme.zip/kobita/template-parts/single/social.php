<?php if( kobita_get_option( 'single_share' ) && function_exists('binarypoets_ess_share') ): ?>
	<?php binarypoets_ess_share(); ?>
<?php endif; ?>