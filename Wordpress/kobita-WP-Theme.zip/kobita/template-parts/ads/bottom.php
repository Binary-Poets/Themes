<?php if( kobita_can_display_ads() && $ad = kobita_get_option('ad_bottom') ): ?>
    <div class="kobita-ad kobita-ad-bottom"><?php echo do_shortcode( $ad ); ?></div>
<?php endif; ?>