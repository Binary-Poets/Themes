<?php
    $cover_media =  kobita_cover_media();
    $cover_media_class = !empty($cover_media) ? 'kobita-cover-overlay' : '';
?>
<div class="kobita-cover-item kobita-cover-single <?php echo esc_attr( $cover_media_class ); ?>">

    <div class="cover-item-container">
        <header class="entry-header">
            <?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
            <?php if( $meta = kobita_meta_display('single') ) : ?>
                <div class="entry-meta"><?php echo kobita_get_meta_data( $meta ); ?></div>
            <?php endif; ?>
        </header>
        <?php if( kobita_get_option('single_dropcap') ) : ?>
            <div class="cover-letter"><?php echo kobita_get_letter(); ?></div>
        <?php endif; ?>
    </div>

    <?php if( $cover_media ) : ?>
        <div class="kobita-cover-img">
            <?php kobita_display_media( $cover_media ); ?>
        </div>
    <?php endif; ?>

</div>