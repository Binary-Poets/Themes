<?php if ( has_nav_menu( 'kobita_social_menu' ) ) : ?>
<li class="kobita-actions-button kobita-social-icons">
	<span>
		<i class="fa fa-share-alt"></i>
	</span>
	<ul class="sub-menu">
        <li>
            <?php wp_nav_menu( array( 'theme_location' => 'kobita_social_menu', 'container'=> '', 'menu_class' => 'kobita-soc-menu', 'link_before' => '<span class="kobita-social-name">', 'link_after' => '</span>' ) ); ?>
        </li>
	</ul>
</li>
<?php endif; ?>