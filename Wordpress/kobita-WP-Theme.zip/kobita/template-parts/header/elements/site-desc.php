<?php if( kobita_header_display('site-desc') ) : ?>
	<span class="kobita-site-description"><?php bloginfo( 'description' ); ?></span>
<?php endif; ?>