<?php $class_hidden = kobita_header_display('sidebar-button') ? '' : 'kobita-mobile-visible'; ?>
<li class="kobita-action-button kobita-action-sidebar <?php echo esc_attr($class_hidden); ?>">
		<span>
			<i class="fa fa-bars"></i>
		</span>
</li>
