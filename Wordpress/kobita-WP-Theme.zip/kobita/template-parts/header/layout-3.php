<div class="slot-l">
	<?php get_template_part('template-parts/header/elements/main-menu'); ?>
</div>

<div class="slot-c">
	<?php get_template_part('template-parts/header/elements/logo'); ?>
</div>

<div class="slot-r">
    <?php get_template_part('template-parts/header/elements/actions'); ?>
</div>