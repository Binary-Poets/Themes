<?php get_header(); ?>

<?php $can_display_cover = kobita_get_option('front_page_cover_on_first_page') && is_paged() ? false : true; ?>
<?php $cover_class = !kobita_get_option( 'front_page_cover' ) || ( kobita_get_option( 'front_page_cover' ) && !$can_display_cover ) ? 'kobita-cover-empty' : ''; ?>

<div id="kobita-cover" class="kobita-cover <?php echo esc_attr($cover_class); ?>">
	<?php if( $can_display_cover && ( $front_page_cover = kobita_get_option( 'front_page_cover' ) ) ) :  ?>
		<?php get_template_part('template-parts/cover/cover-'. $front_page_cover ); ?>
        <?php if(kobita_get_option( 'scroll_down_arrow' )): ?>
            <a href="javascript:void(0)" class="kobita-scroll-down-arrow"><i class="fa fa-angle-down"></i></a>
        <?php endif; ?>
	<?php endif; ?>
</div>

<div class="kobita-fake-bg">
	<div class="kobita-section">
		<?php get_template_part('template-parts/ads/top'); ?>
	
		<?php $can_display_intro = kobita_get_option('front_page_intro_on_first_page') && is_paged() ? false : true; ?>
  
		<?php if( have_posts() && $can_display_intro ): ?>

			<?php while( have_posts() ) : the_post(); ?>

				<?php if( strpos( kobita_get_option( 'front_page_intro' ), 'title' ) !== false ) :  ?>
					<?php kobita_section_heading( array( 'title' => get_the_title() ) ); ?>
				<?php endif; ?>
		
				<?php if( strpos( kobita_get_option( 'front_page_intro' ), 'content' ) !== false  ) :  ?>
					<div class="section-content">
						<?php the_content(); ?>
					</div>
				<?php endif; ?>
    
			<?php endwhile; ?>

		<?php endif; ?>


		<?php if( kobita_get_option( 'front_page_posts') ) : ?>

			<?php kobita_section_heading( array( 'title' => __kobita('latest_stories') ) ); ?>
			<?php $front_page_layout = kobita_get_option( 'front_page_posts_layout'); ?>
			<?php $front_page_query = kobita_get_front_page_posts(); ?>
			
			<?php if( $front_page_query->have_posts() ): ?>

				<div class="section-content section-content-<?php echo esc_attr( $front_page_layout ); ?>">
					
					<div class="kobita-posts">

						<?php while( $front_page_query->have_posts() ) : $front_page_query->the_post(); ?>
                            
                            <?php $ad_class = kobita_has_ad_between( $front_page_query->current_post ) ? 'kobita-has-ad' : ''; ?>
                            
                            <?php include locate_template('template-parts/layouts/content-'. $front_page_layout . '.php'); ?>
                        
                            <?php if( kobita_has_ad_between( $front_page_query->current_post ) ): ?>
                                <?php include locate_template('template-parts/ads/between-posts.php'); ?>
                            <?php endif; ?>
                            
						<?php endwhile; ?>

					</div>

					<?php
						$temp_query = $wp_query;
						$wp_query = $front_page_query;
						get_template_part('template-parts/pagination/'. kobita_get_option( 'front_page_posts_pagination') );
						$wp_query = $temp_query;
					?>

				</div>

			<?php endif; ?>

			<?php wp_reset_postdata(); ?>

		<?php endif; ?>
		
		<?php get_template_part('template-parts/ads/bottom'); ?>
	</div>


<?php get_footer(); ?>
