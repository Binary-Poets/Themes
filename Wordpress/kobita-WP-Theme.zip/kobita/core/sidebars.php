<?php

/**
 * Register sidebars
 *
 * Callback function for theme sidebars registration and init
 * 
 * @since  1.0
 */

add_action( 'widgets_init', 'kobita_register_sidebars' );

if ( !function_exists( 'kobita_register_sidebars' ) ) :
	function kobita_register_sidebars() {
		
		/* Default Sidebar */
		register_sidebar(
			array(
				'id' => 'kobita_default_sidebar',
				'name' => esc_html__( 'Default Sidebar', 'kobita' ),
				'description' => esc_html__( 'This is default sidebar', 'kobita' ),
				'before_widget' => '<div id="%1$s" class="widget clearfix %2$s">',
				'after_widget' => '</div>',
				'before_title' => '<h4 class="widget-title h5">',
				'after_title' => '</h4>'
			)
		);


		/* Footer Left */
		register_sidebar(
			array(
				'id' => 'kobita_footer_sidebar_left',
				'name' => esc_html__( 'Footer Left', 'kobita' ),
				'description' => esc_html__( 'This is footer left column', 'kobita' ),
				'before_widget' => '<div id="%1$s" class="widget clearfix %2$s">',
				'after_widget' => '</div>',
				'before_title' => '<h4 class="widget-title h5">',
				'after_title' => '</h4>'
			)
		);

		/* Footer Center */
		register_sidebar(
			array(
				'id' => 'kobita_footer_sidebar_center',
				'name' => esc_html__( 'Footer Center', 'kobita' ),
				'description' => esc_html__( 'This footer center column', 'kobita' ),
				'before_widget' => '<div id="%1$s" class="widget clearfix %2$s">',
				'after_widget' => '</div>',
				'before_title' => '<h4 class="widget-title h5">',
				'after_title' => '</h4>'
			)
		);


		/* Footer Right */
		register_sidebar(
			array(
				'id' => 'kobita_footer_sidebar_right',
				'name' => esc_html__( 'Footer Right', 'kobita' ),
				'description' => esc_html__( 'This footer right column', 'kobita' ),
				'before_widget' => '<div id="%1$s" class="widget clearfix %2$s">',
				'after_widget' => '</div>',
				'before_title' => '<h4 class="widget-title h5">',
				'after_title' => '</h4>'
			)
		);

		/* WooCommerce Sidebar */
		if ( kobita_is_woocommerce_active()) {	
			register_sidebar(
				array(
					'id' => 'kobita_woocommerce_sidebar',
					'name' => esc_html__( 'WooCommerce Sidebar', 'kobita' ),
					'description' => esc_html__( 'This sidebar will show on WooCommerce pages', 'kobita' ),
					'before_widget' => '<div id="%1$s" class="widget clearfix %2$s">',
					'after_widget' => '</div>',
					'before_title' => '<h4 class="widget-title h5">',
					'after_title' => '</h4>'
				)
			);
		}

	}

endif;




?>