<?php

/**
 * Include the TGM_Plugin_Activation class.
 */

require_once get_parent_theme_file_path( '/inc/tgm/class-tgm-plugin-activation.php' );

/**
 * Register the required plugins for this theme.
 *
 */

add_action( 'tgmpa_register', 'kobita_register_required_plugins' );

function kobita_register_required_plugins() {

	/**
	 * Array of plugin params
	 */
	$plugins = array(
		array(
			'name'   => 'Redux Framework',
			'slug'   => 'redux-framework',
			'required'  => true,
		),
		array(
			'name'   => 'Binary Flexible Shortcodes',
			'slug'   => 'binary-flexible-shortcodes',
						'source' => 'https://binary-poets.github.io/plugins/kobita/binary-flexible-shortcodes.zip',
		),
		array(
			'name'   => 'Binary Easy Ads Widget',
			'slug'   => 'binary-easy-ads-widget',
				'source' => 'https://binary-poets.github.io/plugins/kobita/binary-easy-ads-widget.zip',
		),
		array(
			'name'   => 'Binary Smart Social Widget',
			'slug'   => 'binary-smart-social-widget',
					'source' => 'https://binary-poets.github.io/plugins/kobita/binary-smart-social-widget.zip',
		),
		array(
			'name'   => 'Binary Smart Author Widget',
			'slug'   => 'binary-smart-author-widget',
					'source' => 'https://binary-poets.github.io/plugins/kobita/binary-smart-author-widget.zip',
		),
		array(
			'name'   => 'Binary Simple Flickr Widget',
			'slug'   => 'binary-simple-flickr-widget',
					'source' => 'https://binary-poets.github.io/plugins/kobita/binary-simple-flickr-widget.zip',
		),
		array(
			'name'   => 'Binary ThemeForest Smart Widget',
			'slug'   => 'binary-themeforest-smart-widget',
					'source' => 'https://binary-poets.github.io/plugins/kobita/binary-themeforest-smart-widget.zip',
		),

		array(
			'name'   => 'Binary Easy Instagram Widget',
			'slug'   => 'binary-easy-instagram-widget',
					'source' => 'https://binary-poets.github.io/plugins/kobita/binary-easy-instagram-widget.zip',
		),
		array(
			'name'   => 'Binary Easy Social Share',
			'slug'   => 'binary-easy-social-share',
					'source' => 'https://binary-poets.github.io/plugins/kobita/binary-easy-social-share.zip',
		),
		array(
			'name' 	=> 'Moment Ago',
			'slug' 	=> 'moment-ago',
			'source' => 'https://binaryassets.github.io/BinaryExtra/moment-ago.zip',
		),
		array(
			'name' 		=> 'WPForms Lite',
			'slug' 		=> 'wpforms-lite',
		),
		array(
			'name'   => 'Force Regenerate Thumbnails',
			'slug'   => 'force-regenerate-thumbnails',
		),
		array(
			'name' 		=> 'Envato Market',
			'slug' 		=> 'envato-market',
			'required' 	=> false,
			'source'    => 'https://envato.github.io/wp-envato-market/dist/envato-market.zip',
			'external_url' => 'https://envato.com/market-plugin/'
		),
		array(
			'name'	   => 'Kobita Extra',
			'slug'     => 'kobita-extra',
			'required' => true,
			'source' 	=> 'https://binaryassets.github.io/BinaryExtra/kobita-extra.zip',
		),
			array(
			'name'   => 'Wp Brand Manager',
			'slug'   => 'wp-brand-manager',
			'source' => 'https://binary-poets.github.io/plugins/WPBrandManager.zip',
		),

	);


	/**
	 * Array of configuration settings.
	 */
	$config = array(
		'domain'         => 'kobita',
		'default_path'   => '',
		'menu'           => 'install-required-plugins',
		'has_notices'       => false,
		'is_automatic'     => true,
		'message'    => '',
		'strings'        => array(
			'page_title'                          => esc_html__( 'Install Recommended Plugins', 'kobita' ),
			'menu_title'                          => esc_html__( 'Kobita Plugins', 'kobita' ),
			'installing'                          => esc_html__( 'Installing Plugin: %s', 'kobita' ), // %1$s = plugin name
			'oops'                                => esc_html__( 'Something went wrong with the plugin API.', 'kobita' ),
			'notice_can_install_required'        => _n_noop( 'This theme requires the following plugin: %1$s.', 'This theme requires the following plugins: %1$s.', 'kobita' ), // %1$s = plugin name(s)
			'notice_can_install_recommended'   => _n_noop( 'This theme recommends the following plugin: %1$s.', 'This theme recommends the following plugins: %1$s.', 'kobita' ), // %1$s = plugin name(s)
			'notice_cannot_install'       => _n_noop( 'Sorry, but you do not have the correct permissions to install the %s plugin. Contact the administrator of this site for help on getting the plugin installed.', 'Sorry, but you do not have the correct permissions to install the %s plugins. Contact the administrator of this site for help on getting the plugins installed.', 'kobita' ), // %1$s = plugin name(s)
			'notice_can_activate_required'       => _n_noop( 'The following required plugin is currently inactive: %1$s.', 'The following required plugins are currently inactive: %1$s.', 'kobita' ), // %1$s = plugin name(s)
			'notice_can_activate_recommended'   => _n_noop( 'The following recommended plugin is currently inactive: %1$s.', 'The following recommended plugins are currently inactive: %1$s.', 'kobita' ), // %1$s = plugin name(s)
			'notice_cannot_activate'      => _n_noop( 'Sorry, but you do not have the correct permissions to activate the %s plugin. Contact the administrator of this site for help on getting the plugin activated.', 'Sorry, but you do not have the correct permissions to activate the %s plugins. Contact the administrator of this site for help on getting the plugins activated.', 'kobita' ), // %1$s = plugin name(s)
			'notice_ask_to_update'       => _n_noop( 'The following plugin needs to be updated to its latest version to ensure maximum compatibility with this theme: %1$s.', 'The following plugins need to be updated to their latest version to ensure maximum compatibility with this theme: %1$s.', 'kobita' ), // %1$s = plugin name(s)
			'notice_cannot_update'       => _n_noop( 'Sorry, but you do not have the correct permissions to update the %s plugin. Contact the administrator of this site for help on getting the plugin updated.', 'Sorry, but you do not have the correct permissions to update the %s plugins. Contact the administrator of this site for help on getting the plugins updated.', 'kobita' ), // %1$s = plugin name(s)
			'install_link'           => _n_noop( 'Begin installing plugin', 'Begin installing plugins', 'kobita' ),
			'activate_link'          => _n_noop( 'Activate installed plugin', 'Activate installed plugins', 'kobita' ),
			'return'                              => esc_html__( 'Return to Required Plugins Installer', 'kobita' ),
			'plugin_activated'                    => esc_html__( 'Plugin activated successfully.', 'kobita' ),
			'complete'          => esc_html__( 'All plugins installed and activated successfully. %s', 'kobita' ),
			'nag_type'         => 'updated'
		)
	);

	tgmpa( $plugins, $config );

}

?>