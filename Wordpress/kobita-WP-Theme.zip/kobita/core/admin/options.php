<?php


if ( ! class_exists( 'Redux' ) ) {
    return;
}

/**
 * Redux params
 */

$opt_name = 'kobita_settings';

$args = array(
    'opt_name'             => $opt_name,
    'display_name'         => wp_kses( sprintf( __( 'Kobita Options%sTheme Documentation%s', 'kobita' ), '<a href="http://binarypoets.net/kobita/documentation/" target="_blank">', '</a>' ), wp_kses_allowed_html( 'post' )),
    'display_version'      => kobita_get_update_notification(),
    'menu_type'            => 'menu',
    'allow_sub_menu'       => true,
    'menu_title'           => esc_html__( 'Theme Options', 'kobita' ),
    'page_title'           => esc_html__( 'Kobita Options', 'kobita' ),
    'google_api_key'       => '',
    'google_update_weekly' => false,
    'async_typography'     => true,
    'admin_bar'            => true,
    'admin_bar_icon'       => 'dashicons-admin-generic',
    'admin_bar_priority'   => '100',
    'global_variable'      => '',
    'dev_mode'             => false,
    'update_notice'        => false,
    'customizer'           => false,
    'allow_tracking' => false,
    'ajax_save' => false,
    'page_priority'        => '27.11',
    'page_parent'          => 'themes.php',
    'page_permissions'     => 'manage_options',
    'menu_icon'            => 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAxNjAwIDE2MDAiPiAgPHBhdGggZmlsbD0iIzlGQTRBOSIgZD0iTTI0NSAyNDV2MTExMGgxMTEwVjI0NUgyNDV6bTU1NS45IDU1OGgtMTI1djI2NC44SDc5OHYxMTdINTQ4LjhWODAzaC04MS4xVjY4Ni4xaDgxLjFWNDc2LjZoMTI3djIwOS41aDEyNVY4MDN6Ii8+PC9zdmc+',
    'last_tab'             => '',
    'page_icon'            => 'icon-themes',
    'page_slug'            => 'kobita_options',
    'save_defaults'        => true,
    'default_show'         => false,
    'default_mark'         => '',
    'show_import_export'   => true,
    'transient_time'       => 60 * MINUTE_IN_SECONDS,
    'output'               => false,
    'output_tag'           => true,
    'database'             => '',
    'system_info'          => false
);

$GLOBALS['redux_notice_check'] = 1;

/* Footer social icons */

$args['share_icons'][] = array(
    'url'   => 'https://www.facebook.com/binarypoets',
    'title' => 'Like us on Facebook',
    'icon'  => 'el-icon-facebook'
);

$args['share_icons'][] = array(
    'url'   => 'http://twitter.com/binarypoets',
    'title' => 'Follow us on Twitter',
    'icon'  => 'el-icon-twitter'
);

$args['intro_text'] = '';
$args['footer_text'] = '';


/**
 * Initialize Redux
 */

Redux::setArgs( $opt_name , $args );


/**
 * Include redux option fields (settings)
 */

include_once get_parent_theme_file_path( '/core/admin/options-fields.php' );


/**
 * Check if there is available theme update
 *
 * @return string HTML output with update notification and the link to change log
 * @since  1.0
 */


function kobita_get_update_notification() {
    $current = get_site_transient( 'update_themes' );
    $message_html = '';
    if ( isset( $current->response['kobita'] ) ) {
        $message_html = '<span class="update-message">New update available!</span>
            <span class="update-actions">Version '.$current->response['kobita']['new_version'].': <a href="http://binarypoets.net/docs/kobita-change-log" target="blank">See what\'s new</a><a href="'.admin_url( 'update-core.php' ).'">Update</a></span>';
    } else {
        $message_html = '<a class="theme-version-label" href="https://binarypoets.net/docs/kobita-change-log" target="blank">Version '.KOBITA_THEME_VERSION.'</a>';
    }

    return $message_html;
}


/**
 * Append custom css to redux framework admin panel
 *
 * @since  1.0
 */

if ( !function_exists( 'kobita_redux_custom_css' ) ):
    function kobita_redux_custom_css() {
        wp_register_style( 'kobita-redux-custom', get_parent_theme_file_uri('/assets/css/admin/options.css'), array( 'redux-admin-css' ), KOBITA_THEME_VERSION );
        wp_enqueue_style( 'kobita-redux-custom' );
    }
endif;

add_action( 'redux/page/kobita_settings/enqueue', 'kobita_redux_custom_css' );




/**
 * Remove redux framework admin page
 *
 * @since  1.0
 */

if ( !function_exists( 'kobita_remove_redux_page' ) ):
    function kobita_remove_redux_page() {
        remove_submenu_page( 'tools.php', 'redux-about' );
    }
endif;

add_action( 'admin_menu', 'kobita_remove_redux_page', 99 );

/* Prevent redux auto redirect */
update_option( 'redux_version_upgraded_from', 100 );


/* More redux cleanup, blah... */

add_action( 'init', 'kobita_redux_cleanup' );

if ( !function_exists( 'kobita_redux_cleanup' ) ):
	function kobita_redux_cleanup() {
		
		if ( class_exists( 'ReduxFrameworkPlugin' ) ) {
			remove_action( 'admin_notices', array( ReduxFrameworkPlugin::get_instance(), 'admin_notices' ) );
		}
	}
endif;

/**
 * Add section custom field to redux
 *
 * @since  1.0
 */

if ( !function_exists( 'kobita_section_field_path' ) ):
	function kobita_section_field_path( $field ) {
		return get_parent_theme_file_path( '/core/admin/options-custom-fields/section/section.php' );
	}
endif;

add_filter( "redux/kobita_settings/field/class/kobita_section", "kobita_section_field_path" );

?>
