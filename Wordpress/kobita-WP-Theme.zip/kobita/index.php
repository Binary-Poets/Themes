<?php get_header(); ?>
<?php $cover_class = !kobita_get_archive_option( 'cover' ) ? 'kobita-cover-empty' : ''; ?>
<div id="kobita-cover" class="kobita-cover <?php echo esc_attr( $cover_class ); ?>">
	<?php get_template_part( 'template-parts/cover/cover-archive' ); ?>
	<?php if ( kobita_get_option( 'scroll_down_arrow' ) ): ?>
        <a href="javascript:void(0)" class="kobita-scroll-down-arrow"><i class="fa fa-angle-down"></i></a>
	<?php endif; ?>
</div>

<div class="kobita-fake-bg">
	<div class="kobita-section">
		<?php get_template_part( 'template-parts/ads/top' ); ?>

		<?php if ( !kobita_get_archive_option( 'cover' ) ) : ?>
			<?php $heading = kobita_get_archive_heading(); ?>
			<?php kobita_section_heading( array( 'title' => $heading['title'],  'pre' => $heading['pre'], 'element' => 'h1' , 'avatar' => $heading['avatar'], 'desc' => $heading['desc'] ) ); ?>
		<?php endif; ?>

		<?php $archive_layout = kobita_get_archive_option( 'layout' ); ?>

		<?php if ( have_posts() ) : ?>

			<div class="section-content section-content-<?php echo esc_attr( $archive_layout ); ?>">

				<div class="kobita-posts">

					<?php while ( have_posts() ) : the_post(); ?>

						<?php $ad_class = kobita_has_ad_between( $wp_query->current_post )  ? 'kobita-has-ad' : ''; ?>

                        <?php include locate_template( 'template-parts/layouts/content-'. $archive_layout . '.php' ); ?>

						<?php if ( kobita_has_ad_between( $wp_query->current_post ) ): ?>
							<?php include locate_template( 'template-parts/ads/between-posts.php' ); ?>
						<?php endif; ?>

					<?php endwhile; ?>

				</div>

				<?php get_template_part( 'template-parts/pagination/'. kobita_get_archive_option( 'pagination' ) ); ?>

			</div>

		<?php else: ?>

			<?php get_template_part( 'template-parts/layouts/content-none' ); ?>

		<?php endif; ?>

		<?php get_template_part( 'template-parts/ads/bottom' ); ?>
	</div>

<?php get_footer(); ?>
