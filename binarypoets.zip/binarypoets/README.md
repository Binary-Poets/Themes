# BinaryPoets

**Contributors:** Nicolas, Alex, Amit, and Marko
**Requires at least:** WordPress 4.4
**Tested up to:** WordPress 5.3
**Stable tag:** 1.7.4
**License:** GPLv3 or later
**License URI:** http://www.gnu.org/licenses/gpl-3.0.html
**Tags:** two-columns, right-sidebar, footer-widgets, blog, news, custom-background, custom-menu, post-formats, rtl-language-support, sticky-post, editor-style, threaded-comments, translation-ready, buddypress, custom-colors, featured-images, full-width-template, theme-options, e-commerce

## Description
*BinaryPoets* is a Multi-Purpose [WordPress](http://wordpress.org) theme, designed and built by [Binary Poets](https://oceanwp.org/) to help you to create unique websites. It's available to download for free at the site [BinaryPoets](https://oceanwp.org/).

For developers, BinaryPoets is the perfect starting point for your project. Its clean and extensible codebase will allow you to easily add functionality to your site via child theme and/or custom plugin(s).

## BinaryPoets extensions
Looking to make your website to the next level? Be sure to checkout the premium [BinaryPoets extensions](https://oceanwp.org/extensions/).

## BinaryPoets help & support
Customers can get support at the [BinaryPoets support page](https://oceanwp.org/support/). Please remember, github is for bug reports and contributions, _not_ support.

## Contributing to BinaryPoets
If you have a patch, or stumbled you've upon an issue with BinaryPoets core, you can contribute this back to the code. Please read our [contributor guidelines](https://github.com/binarypoets/binarypoets/blob/master/CONTRIBUTING.md) for more information about how you can do this.