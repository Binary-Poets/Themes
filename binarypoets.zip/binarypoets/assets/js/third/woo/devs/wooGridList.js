var $j = jQuery.noConflict();

$j( document ).on( 'ready', function() {
	"use strict";
    // Woo catalog view
    binarypoetsWooGridList();
} );

/* ==============================================
WOOCOMMERCE GRID LIST VIEW
============================================== */
function binarypoetsWooGridList() {
	"use strict"

	if ( $j( 'body' ).hasClass( 'has-grid-list' ) ) {

		// Re-run function
		var binarypoetsProductSlider = function() {
			if ( ! $j( 'body' ).hasClass( 'no-carousel' )
				&& $j( '.woo-entry-image.product-entry-slider' ).length) {
                setTimeout( function() {
                    $j( '.woo-entry-image.product-entry-slider' ).slick( 'unslick' );
                    binarypoetsInitCarousel();
                }, 350 );
            }
        }

		$j( '#binarypoets-grid' ).on( 'click', function() {
			binarypoetsProductSlider();

			$j( this ).addClass( 'active' );
			$j( '#binarypoets-list' ).removeClass( 'active' );
			Cookies.set( 'gridcookie', 'grid', { path: '' } );
			$j( '.woocommerce ul.products' ).fadeOut( 300, function() {
				$j( this ).addClass( 'grid' ).removeClass( 'list' ).fadeIn( 300 );
			} );
			return false;
		} );

		$j( '#binarypoets-list' ).on( 'click', function() {
			binarypoetsProductSlider();
            
			$j( this ).addClass( 'active' );
			$j( '#binarypoets-grid' ).removeClass( 'active' );
			Cookies.set( 'gridcookie', 'list', { path: '' } );
			$j( '.woocommerce ul.products' ).fadeOut( 300, function() {
				$j( this ).addClass( 'list' ).removeClass( 'grid' ).fadeIn( 300 );
			} );
			return false;
		} );

		if ( Cookies.get( 'gridcookie' ) == 'grid' ) {
	        $j( '.binarypoets-grid-list #binarypoets-grid' ).addClass( 'active' );
	        $j( '.binarypoets-grid-list #binarypoets-list' ).removeClass( 'active' );
	        $j( '.woocommerce ul.products' ).addClass( 'grid' ).removeClass( 'list' );
	    }

	    if ( Cookies.get( 'gridcookie' ) == 'list' ) {
	        $j( '.binarypoets-grid-list #binarypoets-list' ).addClass( 'active' );
	        $j( '.binarypoets-grid-list #binarypoets-grid' ).removeClass( 'active' );
	        $j( '.woocommerce ul.products' ).addClass( 'list' ).removeClass( 'grid' );
	    }

	} else {

		Cookies.remove( 'gridcookie', { path: '' } );

	}

}