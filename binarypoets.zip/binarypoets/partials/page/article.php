<?php
/**
 * Outputs page article
 *
 * @package BinaryPoets WordPress theme
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
} ?>

<div class="entry clr"<?php binarypoets_schema_markup( 'entry_content' ); ?>>
	<?php do_action( 'binary_before_page_entry' ); ?>
	<?php the_content();

	wp_link_pages( array(
		'before' => '<div class="page-links">' . __( 'Pages:', 'binarypoets' ),
		'after'  => '</div>',
	) ); ?>
	<?php do_action( 'binary_after_page_entry' ); ?>
</div>