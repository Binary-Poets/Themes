<?php
/**
 * Post single content
 *
 * @package BinaryPoets WordPress theme
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
} ?>

<?php do_action( 'binary_before_single_post_content' ); ?>

<div class="entry-content clr"<?php binarypoets_schema_markup( 'entry_content' ); ?>>
	<?php the_content();

	wp_link_pages( array(
		'before'      => '<div class="page-links">' . __( 'Pages:', 'binarypoets' ),
		'after'       => '</div>',
		'link_before' => '<span class="page-number">',
		'link_after'  => '</span>',
	) ); ?>
</div><!-- .entry -->

<?php do_action( 'binary_after_single_post_content' ); ?>