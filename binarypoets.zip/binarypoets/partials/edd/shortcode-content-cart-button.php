<div class="edd_download_buy_button">
	<?php echo binarypoets_edd_add_to_cart_link(); ?>
</div>
