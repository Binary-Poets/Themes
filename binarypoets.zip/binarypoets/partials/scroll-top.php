<?php
/**
 * The template for displaying the scroll top button.
 *
 * @package BinaryPoets WordPress theme
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// If no scroll top button
if ( ! binarypoets_display_scroll_up_button() ) {
	return;
}

// Get arrow
$arrow = apply_filters( 'binary_scroll_top_arrow', get_theme_mod( 'binary_scroll_top_arrow' ) );
$arrow = $arrow ? $arrow : 'fa fa-angle-up'; 

// Position
$position = apply_filters( 'binary_scroll_top_position', get_theme_mod( 'binary_scroll_top_position' ) );
$position = $position ? $position : 'right'; ?>

<a id="scroll-top" class="scroll-top-<?php echo esc_attr( $position ); ?>" href="#"><span class="<?php echo esc_attr( $arrow ); ?>"></span></a>