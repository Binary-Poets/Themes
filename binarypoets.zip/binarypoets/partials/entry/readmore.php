<?php
/**
 * Displays post entry read more
 *
 * @package BinaryPoets WordPress theme
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Text
$text = esc_html__( 'Continue Reading', 'binarypoets' );

// Apply filters for child theming
$text = apply_filters( 'binary_post_readmore_link_text', $text ); ?>

<?php do_action( 'binary_before_blog_entry_readmore' ); ?>

<div class="blog-entry-readmore clr">
    <a href="<?php the_permalink(); ?>" title="<?php echo esc_attr( $text ); ?>"><?php echo esc_html( $text ); ?><i class="fa fa-angle-right"></i></a>
</div><!-- .blog-entry-readmore -->

<?php do_action( 'binary_after_blog_entry_readmore' ); ?>