<?php
/**
 * Blog entry audio format media
 *
 * @package BinaryPoets WordPress theme
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Return if Binary Extra is not active
if ( ! BINARY_EXTRA_ACTIVE ) {
	return;
} ?>

<?php $audio = binarypoets_get_post_audio_html(); ?>

<?php if ( $audio ) : ?>
	
	<div class="thumbnail"><?php echo $audio; ?></div>

<?php
// Else display post thumbnail
else : ?>

	<?php get_template_part( 'partials/entry/media/blog-entry' ); ?>

<?php endif; ?>