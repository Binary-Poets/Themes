<?php
/**
 * Outputs correct library layout
 *
 * @package BinaryPoets WordPress theme
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
} ?>

<article class="single-library-article clr">

	<div class="entry clr"<?php binarypoets_schema_markup( 'entry_content' ); ?>>
		<?php the_content(); ?>
	</div>

</article>