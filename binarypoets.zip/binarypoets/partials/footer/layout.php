<?php
/**
 * Footer layout
 *
 * @package BinaryPoets WordPress theme
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
} ?>

<footer id="footer" class="<?php echo esc_attr( binarypoets_footer_classes() ); ?>"<?php binarypoets_schema_markup( 'footer' ); ?>>

    <?php do_action( 'binary_before_footer_inner' ); ?>

    <div id="footer-inner" class="clr">

        <?php
        // Display the footer widgets if enabled
        if ( binarypoets_display_footer_widgets() ) {
        	get_template_part( 'partials/footer/widgets' );
        }

        // Display the footer bottom if enabled
        if ( binarypoets_display_footer_bottom() ) {
        	get_template_part( 'partials/footer/copyright' );
        } ?>
        
    </div><!-- #footer-inner -->

    <?php do_action( 'binary_after_footer_inner' ); ?>

</footer><!-- #footer -->