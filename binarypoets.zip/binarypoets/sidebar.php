<?php
/**
 * The sidebar containing the main widget area.
 *
 * @package BinaryPoets WordPress theme
 */

// Retunr if full width or full screen
if ( in_array( binarypoets_post_layout(), array( 'full-screen', 'full-width' ) ) ) {
	return;
} ?>

<?php do_action( 'binary_before_sidebar' ); ?>

<aside id="right-sidebar" class="sidebar-container widget-area sidebar-primary"<?php binarypoets_schema_markup( 'sidebar' ); ?>>

	<?php do_action( 'binary_before_sidebar_inner' ); ?>

	<div id="right-sidebar-inner" class="clr">

		<?php
		if ( $sidebar = binarypoets_get_sidebar() ) {
			dynamic_sidebar( $sidebar );
		} ?>

	</div><!-- #sidebar-inner -->

	<?php do_action( 'binary_after_sidebar_inner' ); ?>

</aside><!-- #right-sidebar -->

<?php do_action( 'binary_after_sidebar' ); ?>