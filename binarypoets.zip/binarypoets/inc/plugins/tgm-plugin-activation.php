<?php
/**
 * Recommends plugins for use with the theme via the TGMA Script
 *
 * @package BinaryPoets WordPress theme
 */

function binarypoets_tgmpa_register() {

	// Get array of recommended plugins
	$plugins = array(

		array(
			'name'				=> 'Binary Extra',
			'slug'				=> 'binary-extra',
			'required'			=> false,
			'force_activation'	=> false,
			'src'		=>	'https://binary-poets.github.io/plugins/binary/binary-extra.zip',
		),

		array(
			'name'				=> 'Elementor',
			'slug'				=> 'elementor',
			'required'			=> false,
			'force_activation'	=> false,
		),

	);

	// If WPForms Pro is not active, recommend WPForms
	if ( ! class_exists( 'WPForms_Pro' ) ) {
		$plugins[] = array(
			'name'				=> 'WPForms',
			'slug'				=> 'wpforms-lite',
			'required'			=> false,
			'force_activation'	=> false,
		);
	}

	// Register notice
	tgmpa( $plugins, array(
		'id'           => 'binarypoets_theme',
		'domain'       => 'binarypoets',
		'menu'         => 'install-required-plugins',
		'has_notices'  => true,
		'is_automatic' => true,
		'dismissable'  => true,
	) );

}
add_action( 'tgmpa_register', 'binarypoets_tgmpa_register' );