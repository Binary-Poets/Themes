<?php
/**
 * bbPress class
 *
 * @package BinaryPoets WordPress theme
 */

// If bbPress plugins doesn't exist then return.
if ( ! class_exists( 'bbPress' ) ) {
	return;
}

if ( ! class_exists( 'BinaryPoets_bbPress' ) ) :

	class BinaryPoets_bbPress {

		/**
		 * Setup class.
		 *
		 * @since 1.4.0
		 */
		public function __construct() {
			add_action( 'wp_enqueue_scripts', array( $this, 'add_custom_css' ) );
		}

		/**
		 * Load custom CSS file
		 *
		 * @since 1.4.3
		 */
		public static function add_custom_css() {
			wp_enqueue_style( 'binarypoets-bbpress', BINARYPOETS_CSS_DIR_URI .'third/bbpress.min.css' );
		}

	}

endif;

return new BinaryPoets_bbPress();