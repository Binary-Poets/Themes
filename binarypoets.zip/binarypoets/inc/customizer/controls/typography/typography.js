( function($) {

	$( document ).ready(function () {

		$( '.binarypoets-typography-select' ).select2();

	} );

} )( jQuery );