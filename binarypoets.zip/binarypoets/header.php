<?php
/**
 * The Header for our theme.
 *
 * @package BinaryPoets WordPress theme
 */ ?>

<!DOCTYPE html>
<html class="<?php echo esc_attr( binarypoets_html_classes() ); ?>" <?php language_attributes(); ?><?php binarypoets_schema_markup( 'html' ); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

	<?php do_action( 'binary_before_outer_wrap' ); ?>

	<div id="outer-wrap" class="site clr">

		<?php do_action( 'binary_before_wrap' ); ?>

		<div id="wrap" class="clr">

			<?php do_action( 'binary_top_bar' ); ?>

			<?php do_action( 'binary_header' ); ?>

			<?php do_action( 'binary_before_main' ); ?>
			
			<main id="main" class="site-main clr"<?php binarypoets_schema_markup( 'main' ); ?>>

				<?php do_action( 'binary_page_header' ); ?>
